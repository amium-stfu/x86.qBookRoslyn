﻿using Microsoft.Extensions.Options;
using ScintillaNET;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static qbook.CodeEditor.FormEditor;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.Design.AxImporter;

namespace qbook.CodeEditor
{
    public partial class FormFindReplace : Form
    {

        private readonly FormEditor Root;
        private readonly Scintilla Editor;
        private readonly RoslynServices _roslyn;

        DataTable Result;
        DataGridView View;

        private bool isNewSearch = true;

        class FindReplaceOptions
        {
            public bool MatchCase { get; set; } = false;
            public bool MatchWholeWord { get; set; } = false;
            public bool UseRegularExpressions { get; set; } = false;
            public bool SearchUp { get; set; } = false;
            public bool InSelection { get; set; } = false;
            public bool InDocument { get; set; } = false;
            public bool InProject { get; set; } = false;

        }


      


        FindReplaceOptions Options = new FindReplaceOptions();

        public FormFindReplace(FormEditor parent, RoslynServices roslyn, DataGridView view)
        {
          

            Root = parent;
            _roslyn = roslyn;
            Editor = Root.Editor;
            InitializeComponent();
            btnFindPrevious.Visible = false;
            View = view;
            Hide();
            Init();
        }


        private void Init()
        { 
        
            Result = new DataTable();

            Result.Columns.Add("Page", typeof(string));
            Result.Columns.Add("Position", typeof(int));
            Result.Columns.Add("Length", typeof(int));
            Result.Columns.Add("Description", typeof(string));
            Result.Columns.Add("Node", typeof(EditorNode));

            View.DataBindingComplete += (s, e) =>
            {
                View.Columns["Page"].Width = 100;
                View.Columns["Position"].Visible = false;
                View.Columns["Node"].Visible = false;
                View.Columns["Length"].Visible = false;

                View.Columns["Description"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            };
            View.AllowUserToResizeColumns = false;

            View.DataSource = Result;
            View.AllowUserToResizeColumns = false;
            View.AllowUserToAddRows = false;
            View.RowHeadersVisible = false;
            View.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            View.MultiSelect = false;
            View.ReadOnly = true;
            View.BackgroundColor = Color.White;
            View.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            View.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            View.ColumnHeadersVisible = false;
            View.RowHeadersVisible = false;
            View.Dock = DockStyle.Fill;
            View.AllowUserToAddRows = false;
            View.ScrollBars = ScrollBars.None;
            View.AllowUserToDeleteRows = false;
            View.AllowUserToOrderColumns = true;
            View.AllowUserToResizeColumns = false;
            View.BackgroundColor = System.Drawing.Color.LightGray;
            View.BorderStyle = System.Windows.Forms.BorderStyle.None;
            View.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            View.ColumnHeadersVisible = false;
            View.Dock = System.Windows.Forms.DockStyle.Fill;
            View.Location = new System.Drawing.Point(46, 25);
            View.Margin = new System.Windows.Forms.Padding(0);
            View.Name = "dataGridFindReplace";
            View.Size = new System.Drawing.Size(832, 115);
            View.TabIndex = 0;
            View.DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            View.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            View.CellClick += (s, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    string pageName = View.Rows[e.RowIndex].Cells["Page"].Value.ToString();
                    int pos = (int)View.Rows[e.RowIndex].Cells["Position"].Value;
                    int length = Convert.ToInt32(View.Rows[e.RowIndex].Cells["Length"].Value);
                    EditorNode node = (EditorNode)View.Rows[e.RowIndex].Cells["Node"].Value;
                    JumpToPosition(pos, length, node);
                }
            };



        }


        public void Add(string page, int position, int length, string description, EditorNode node)
        {
            if (Result == null) return;
            Result.Rows.Add(page, position, length, description, node);

            Result.AcceptChanges();
            View.Refresh();
        }


        internal async void JumpToPosition(int pos, int length, EditorNode node)
        {
            await Root.OpenNode(node);
           
            int p = pos;
            int lineNumber = Editor.LineFromPosition(p);
            int col = Editor.GetColumn(p);
            //   Debug.WriteLine("Column number " + col);
            int lineStartPos = Editor.Lines[lineNumber].Position;
            Editor.GotoPosition(lineStartPos);
            Editor.SelectionStart = p;
            Editor.SelectionEnd = p + length;
        }

        public void JumpToIndex(int next)
        {
            int index = View.CurrentRow?.Index ?? -1;

            Debug.WriteLine("SelectedRow = " + index);

            index += next;

            if (index < 0 || index >= View.Rows.Count) return;

            View.Rows[index].Selected = true;
            int pos = (int)View.Rows[index].Cells["Position"].Value;
            int length = Convert.ToInt32(View.Rows[index].Cells["Length"].Value);
            EditorNode node = (EditorNode)View.Rows[index].Cells["Node"].Value;
            JumpToPosition(pos, length, node);
        }




        void findInDocument(string text)
        {
            if (string.IsNullOrEmpty(text)) return;

            Root.TableFindReplaceClear();
            string name = Root.SelectedNode.Name;

            int pos = 0;
            StringComparison comparison = Options.MatchCase ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;

            while ((pos = Editor.Text.IndexOf(text, pos, comparison)) != -1)
            {
                int lineNumber = Editor.LineFromPosition(pos);
                string lineText = Editor.Lines[lineNumber].Text;

                Add(name, pos,text.Length, lineText, Root.SelectedNode);
                pos += text.Length; // Weiter suchen nach dem aktuellen Treffer
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void btnFindPrevious_Click(object sender, EventArgs e)
        {
            JumpToIndex(-1);
        }

        private void btnFindNext_Click(object sender, EventArgs e)
        {
            if (cbTarget.Text == "Document") Options.InDocument = true;

            if (isNewSearch)
            {
                isNewSearch = false;
                if (Options.InDocument)
                {
                    findInDocument(tbFind.Text);
                    btnFindPrevious.Visible = false;
                    JumpToIndex(0);
                }
            }
            else
            {
                JumpToIndex(+1);
            }
        }

        private void btnReplaceNext_Click(object sender, EventArgs e)
        {
           
        }

        private void btnReplaceAll_Click(object sender, EventArgs e)
        {

        }

        private void tbFind_TextChanged(object sender, EventArgs e)
        {
            isNewSearch = true;
        }

        private void tbReplace_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMatchCase_Click(object sender, EventArgs e)
        {
            Options.MatchCase = !Options.MatchCase;
            btnMatchCase.BackColor = Options.MatchCase ? Color.LightBlue : Color.Transparent;  

        }
    }
}
