﻿using DevExpress.DocumentView;
using DevExpress.Utils.DPI;
using DevExpress.Utils.Extensions;
using DevExpress.XtraPrinting.Native;
using IronPython.Runtime.Operations;
using Microsoft.Build.Locator;
using Microsoft.Build.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Classification;
using Microsoft.CodeAnalysis.Completion;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.FindSymbols;
using Microsoft.CodeAnalysis.Formatting;
using Microsoft.CodeAnalysis.Host;
using Microsoft.CodeAnalysis.Host.Mef;
using Microsoft.CodeAnalysis.MSBuild;
using Microsoft.CodeAnalysis.Rename;
using Microsoft.CodeAnalysis.Text;
using Microsoft.VisualStudio.SolutionPersistence.Model;
using QB.Controls;
using qbook.UI;
using ScintillaNET;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization; // force English diagnostics
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions; // add near other using directives
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;

using static qbook.Core;
using AccessibilityCode = Microsoft.CodeAnalysis.Accessibility;
using RoslynDocument = Microsoft.CodeAnalysis.Document; // Alias gegen Kollision mit ScintillaNET.Document

namespace qbook.CodeEditor
{
    public partial class FormEditor : Form
    {

        // Helper to satisfy any legacy references that still call FindDocument from the form level
        private RoslynDocument? FindDocument(string? file) => file == null ? null : _roslyn.GetDocument(file);

        private string? _currentFile;
        private string? _projectRoot;
        private RoslynServices _roslyn = new RoslynServices();
        private System.Windows.Forms.Timer _debounceTimer = new System.Windows.Forms.Timer();

        private enum EditorTheme { Light, Dark }
        private EditorTheme _currentTheme = EditorTheme.Light;

        // Fehler-Highlighting / Tooltips
        private List<(int start, int length, string message)> _errorSpans = new();
        private readonly List<Diagnostic> _currentDiagnostics = new();

        private bool _awaitingCtrlK; // für Tastatur-Akkord (Ctrl+K, Ctrl+C/U)
        private bool _awaitingCtrlM; // für Tastatur-Akkord (Ctrl+M, Ctrl+O/L)
        private readonly System.Windows.Forms.Timer _chordTimer = new() { Interval = 1500 };
        private readonly System.Windows.Forms.Timer _undoTimer = new() { Interval = 1000 };

        private SearchBar _searchBar = new();
        private ReplaceBar _replaceBar = new();
        private int _lastSearchPos = -1;
        private string? _projectSearchPatternCache;
        private string[]? _projectSearchFileCache;
        private int _projectSearchCurrentFileIndex = -1;
        private Point _editorTopRightCache;

        // --- neue Felder für Replace-Projekt-Suche ---
        private string? _replaceProjectPatternCache;
        private string[]? _replaceProjectFileCache;
        private int _replaceProjectCurrentFileIndex = -1;
        private int _replaceProjectLastPos = -1;



        DataTable tblEditorOutputs = new DataTable();
        DataTable tblBuildOutputs = new DataTable();

        DataTable tblMethodes = new DataTable();

        DataGridView dataGridOutput;
        DataGridView dataGridBuild;


        int lastHighlightedStart = -1;
        int lastHighlightedLength = 0;

        EditorNode RootNode;

        void HighlightLine(int lineNumber, System.Drawing.Color color)
        {
            // Vorherige Markierung löschen
            Editor.IndicatorClearRange(16, Editor.TextLength);

            Editor.FirstVisibleLine = lineNumber -17;
            // Neue Positionen berechnen
            int startPos = Editor.Lines[lineNumber].Position;
            int endPos = Editor.Lines[lineNumber].EndPosition;

            // Markierung setzen
            Editor.IndicatorCurrent = 16;
            Editor.Indicators[16].ForeColor = color;
            Editor.IndicatorFillRange(startPos, endPos - startPos);

            // Position merken
            lastHighlightedStart = startPos;
            lastHighlightedLength = endPos - startPos;
        }
        void HighlightText(int startPos, int endPos, System.Drawing.Color color)
        {

            Debug.WriteLine("Highlight " + startPos + ".." + endPos);
            // Vorherige Markierung löschen
            Editor.IndicatorClearRange(16, Editor.TextLength);

            // Markierung setzen
            Editor.IndicatorCurrent = 16;
            Editor.Indicators[16].ForeColor = color;
            Editor.GotoPosition(startPos);
            Editor.IndicatorFillRange(startPos, endPos - startPos);

            // Position merken
            lastHighlightedStart = startPos;
            lastHighlightedLength = endPos - startPos;
        }

        
        public FormEditor()
        {
            InitializeComponent();
            InitOutput();
            tableLayoutPanel3.Controls.Add(this.dataGridOutput, 1, 2);

            tblMethodes.Columns.Add("Row", typeof(int));
            tblMethodes.Columns.Add("Name", typeof(string));
            gridViewMethodes.DataSource = tblMethodes;
            gridViewMethodes.AllowUserToResizeColumns = false;
            gridViewMethodes.AllowUserToAddRows = false;
            gridViewMethodes.RowHeadersVisible = false;
            gridViewMethodes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridViewMethodes.MultiSelect = false;
            gridViewMethodes.ReadOnly = true;
            gridViewMethodes.BackgroundColor = Color.White;
            gridViewMethodes.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            gridViewMethodes.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            gridViewMethodes.ColumnHeadersVisible = false;
            gridViewMethodes.RowHeadersVisible = false;
            gridViewMethodes.Dock = DockStyle.Fill;
            gridViewMethodes.AllowUserToAddRows = false;
            gridViewMethodes.AllowUserToDeleteRows = false;
            gridViewMethodes.AllowUserToOrderColumns = true;
            gridViewMethodes.AllowUserToResizeColumns = false;
            gridViewMethodes.BackgroundColor = System.Drawing.Color.LightGray;
            gridViewMethodes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            gridViewMethodes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            gridViewMethodes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridViewMethodes.ColumnHeadersVisible = false;
            gridViewMethodes.Dock = System.Windows.Forms.DockStyle.Fill;
            gridViewMethodes.Location = new System.Drawing.Point(46, 25);
            gridViewMethodes.TabIndex = 0;

            gridViewMethodes.DataBindingComplete += (s, e) =>
            {
                gridViewMethodes.Columns["Row"].Width = 40;
                gridViewMethodes.Columns["Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            };

            gridViewMethodes.CellClick += (s, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    int line = (int)gridViewMethodes.Rows[e.RowIndex].Cells["Row"].Value -1;
                    HighlightLine(line,Color.Yellow);
                }
            };





            Editor.MouseDown += (s, e) =>
            {
                int currentPos = Editor.CurrentPosition;

                // Prüfen, ob Cursor außerhalb der markierten Zeile liegt
                if (lastHighlightedStart >= 0 &&
                    (currentPos < lastHighlightedStart || currentPos > lastHighlightedStart + lastHighlightedLength))
                {
                    Editor.IndicatorClearRange(16, Editor.TextLength);
                    lastHighlightedStart = -1;
                    lastHighlightedLength = 0;
                }
            };





            vBarEditor.Init(Editor);
            hBarEditor.Init(Editor);
            vBarMethodes.Init(gridViewMethodes);
            vBarProjectTree.Init(ProjectTree, hideNativeScrollbar: true);



            //

            //for deaktivate embedded undo
            Editor.ClearCmdKey(Keys.Control | Keys.Z);
            Editor.ClearCmdKey(Keys.Control | Keys.Y);
            const int SCI_SETUNDOCOLLECTION = 2012;
            try { Editor.DirectMessage(SCI_SETUNDOCOLLECTION, new IntPtr(0), IntPtr.Zero); } catch { /* ignorieren, wenn nicht nötig */ }


            // Grund-Einstellungen verschoben in Theme Methoden

            const int MARGIN_LINE_NUMBERS = 0;
            Editor.Margins[MARGIN_LINE_NUMBERS].Type = MarginType.Number;
            Editor.Margins[MARGIN_LINE_NUMBERS].Width = 40;

            Editor.WhitespaceSize = 2;
            Editor.ViewWhitespace = WhitespaceMode.Invisible;
            Editor.IndentationGuides = IndentView.LookBoth;

            //Highlighting

            // 0 = Errors (hast du)
            Editor.Indicators[0].Style = IndicatorStyle.Squiggle;
            Editor.Indicators[0].ForeColor = Color.Red;
            Editor.Indicators[0].Under = true;

            // 2..9 = Semantik-Overlay (Textfarbe oder Unterstreichung)
            Editor.Indicators[2].Style = IndicatorStyle.TextFore;   // Methoden
            Editor.Indicators[2].Under = true;
            Editor.Indicators[2].ForeColor = Color.DarkOrange;

            Editor.Indicators[3].Style = IndicatorStyle.TextFore;    // Klassen
            Editor.Indicators[3].ForeColor = Color.DarkViolet;

            Editor.Indicators[4].Style = IndicatorStyle.TextFore;    // Interfaces
            Editor.Indicators[4].ForeColor = Color.Red;

            Editor.Indicators[5].Style = IndicatorStyle.TextFore;    // Structs
            Editor.Indicators[5].ForeColor = Color.Firebrick;

            Editor.Indicators[6].Style = IndicatorStyle.TextFore;    // Enums
            Editor.Indicators[6].ForeColor = Color.FromArgb(0xCE, 0x91, 0x78);

            Editor.Indicators[7].Style = IndicatorStyle.TextFore;    // Delegates
            Editor.Indicators[7].ForeColor = Color.FromArgb(0xD4, 0xD4, 0xD4);


            Editor.Indicators[8].Style = IndicatorStyle.TextFore;    // Properties
            Editor.Indicators[8].ForeColor = Color.Black;

            Editor.Indicators[9].Style = IndicatorStyle.TextFore;    // Fields
            Editor.Indicators[9].ForeColor = Color.Black;

            // 10..12 zusätzliche Syntax (Keywords, Zahlen, Strings/Chars)
            Editor.Indicators[10].Style = IndicatorStyle.TextFore; // Keywords
            Editor.Indicators[10].ForeColor = Color.FromArgb(0x00, 0x33, 0xCC);
            Editor.Indicators[11].Style = IndicatorStyle.TextFore; // Numbers
            Editor.Indicators[11].ForeColor = Color.FromArgb(0x00, 0x80, 0x80);
            Editor.Indicators[12].Style = IndicatorStyle.TextFore; // Strings / Chars
            Editor.Indicators[12].ForeColor = Color.FromArgb(0xA3, 0x15, 0x15);

            Editor.Indicators[13].Style = IndicatorStyle.TextFore; // Kommentare
            Editor.Indicators[13].ForeColor = Color.FromArgb(0x00, 0x80, 0x00);

            Editor.Indicators[14].Style = IndicatorStyle.TextFore; // If, Else, Switch,..
            Editor.Indicators[14].ForeColor = Color.FromArgb(0x00, 0x80, 0x00);

            Editor.Indicators[15].Style = IndicatorStyle.TextFore; // If, Else, Switch,..
            Editor.Indicators[15].ForeColor = Color.FromArgb(0x00, 0x80, 0x00);

            Editor.Indicators[16].Style = IndicatorStyle.StraightBox; //FInd Code
            Editor.Indicators[16].ForeColor = Color.Yellow;

            InitializeFolding();
            Editor.Indicators[1].Style = IndicatorStyle.StraightBox;
            Editor.Indicators[1].Under = true;
            Editor.Indicators[1].ForeColor = Color.Red;

            Editor.UpdateUI += (s, e) =>
            {
                var caret = Editor.CurrentPosition;
                var bracePos1 = -1;
                if (caret > 0 && IsBrace(Editor.GetCharAt(caret - 1))) bracePos1 = caret - 1;
                else if (IsBrace(Editor.GetCharAt(caret))) bracePos1 = caret;
                var bracePos2 = bracePos1 >= 0 ? Editor.BraceMatch(bracePos1) : -1;
                Editor.BraceHighlight(bracePos1, bracePos2);
                if ((e.Change & UpdateChange.Selection) != 0 && Editor.CallTipActive)
                {
                    _ = TrySignatureHelpAsync(updateOnly: true);
                }
            };
            Editor.LexerName = "cpp";
            Editor.SetKeywords(0, CsKeywords);
            Editor.UseTabs = false;
            Editor.TabWidth = 4;
            Editor.IndentWidth = 4;
            Editor.WrapMode = WrapMode.None;
  

            KeyPreview = true;

            // Entferne alte/defekte Handler (falls vorhanden)
            Editor.CharAdded -= null; // no-op, Platzhalter
            // Neuer sauberer CharAdded Handler
            Editor.CharAdded += async (s, e) =>
            {

                if (_currentFile == null || !_currentFile.EndsWith(".cs"))
                    return;


                char c = (char)e.Char;

                // Smart Indent bei neuer Zeile
                if (c == '\n')
                {
                    try
                    {
                        int curLine = Editor.LineFromPosition(Editor.CurrentPosition);
                        if (curLine > 0)
                        {
                            var prev = Editor.Lines[curLine - 1];
                            string prevText = prev.Text.TrimEnd('\r', '\n');
                            int indent = prev.Indentation;
                            if (prevText.TrimEnd().EndsWith("{"))
                                indent += Editor.IndentWidth;
                            Editor.Lines[curLine].Indentation = indent;
                            int target = Editor.Lines[curLine].Position + Editor.Lines[curLine].Indentation;
                            Editor.GotoPosition(target);
                        }
                    }
                    catch { }
                    return;
                }

                // Smart Outdent bei '}'
                if (c == '}')
                {
                    try
                    {
                        int bracePos = Editor.CurrentPosition - 1;
                        int match = Editor.BraceMatch(bracePos);
                        if (match < 0)
                        {
                            int depth = 0;
                            for (int i = bracePos - 1; i >= 0; i--)
                            {
                                int ch = Editor.GetCharAt(i);
                                if (ch == '}') depth++;
                                else if (ch == '{')
                                {
                                    if (depth == 0) { match = i; break; }
                                    depth--;
                                }
                            }
                        }
                        int currentLine = Editor.LineFromPosition(bracePos);
                        int targetIndent = 0;
                        if (match >= 0)
                        {
                            int openLine = Editor.LineFromPosition(match);
                            targetIndent = Editor.Lines[openLine].Indentation;
                        }
                        else
                        {
                            for (int l = currentLine - 1; l >= 0; l--)
                            {
                                string raw = Editor.Lines[l].Text.TrimEnd('\r', '\n');
                                if (raw.Trim().Length == 0) continue;
                                if (raw.TrimEnd().EndsWith("{"))
                                    targetIndent = Editor.Lines[l].Indentation;
                                else
                                    targetIndent = Math.Max(0, Editor.Lines[l].Indentation - Editor.IndentWidth);
                                break;
                            }
                        }
                        Editor.Lines[currentLine].Indentation = targetIndent;
                        Editor.GotoPosition(bracePos + 1);
                    }
                    catch { }
                }

                // Signature Help
                if (c == '(' || c == ',')
                    await TrySignatureHelpAsync();
                else if (c == ')' && Editor.CallTipActive)
                    Editor.CallTipCancel();

                // Autocomplete / Using
                if (c == '.')
                {
                    await TryAddUsingForIdentifierBeforeDotAsync();
                    await ShowCompletionAsync();
                    return;
                }
                if (char.IsLetterOrDigit(c) || c == '_')
                {
                    await ShowCompletionAsync();
                }
            };
            _debounceTimer.Interval = 200;
            // detach duplicate earlier Tick handler (kept single consolidated one)
            _debounceTimer.Tick -= async (s, e) => { _debounceTimer.Stop(); await PushBufferToRoslynAsync(); await RefreshSemanticOverlaysAsync(); }; // detach legacy
            _debounceTimer.Tick -= async (s, e) => { _debounceTimer.Stop(); await PushBufferToRoslynAsync(); await RefreshSemanticOverlaysAsync(); await RefreshDiagnosticsAsync(); }; // detach duplicate
            _debounceTimer.Tick += async (s, e) => { _debounceTimer.Stop(); await PushBufferToRoslynAsync(); await RefreshSemanticOverlaysAsync(); await RefreshDiagnosticsAsync(); };
            Editor.TextChanged += (s, e) => { _debounceTimer.Stop(); _debounceTimer.Start(); };

            // Fehler-Tooltip (CallTip) via Dwell
            Editor.MouseDwellTime = 500; // ms
            Editor.DwellStart += (s, e) =>
            {
                if (e.Position < 0) return;
                // Suche erstes Matching
                var hit = _errorSpans.FirstOrDefault(span => e.Position >= span.start && e.Position < span.start + span.length);
                if (hit.length > 0)
                {
                    if (!Editor.CallTipActive) Editor.CallTipShow(e.Position, hit.message);
                }
            };
            Editor.DwellEnd += (s, e) =>
            {
                if (Editor.CallTipActive) Editor.CallTipCancel();
            };

            // Automatisches Folden aktivieren (zeigt +/- Marker und reagiert auf Klicks)
            Editor.AutomaticFold = (AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change);
            Editor.SetFoldFlags(FoldFlags.LineAfterContracted);

            InitEditorContextMenu();
            _chordTimer.Tick += (s, e) => { _awaitingCtrlK = false; _chordTimer.Stop(); };
            _chordTimer.Tick += (s, e) => { _awaitingCtrlM = false; _chordTimer.Stop(); };
            _undoTimer.Tick += (s, e) => 
            { _selectedNode.AddUndo(Editor.Text, Editor.CurrentPosition, Editor.FirstVisibleLine);
                _undoTimer.Stop();
            };


            Editor.KeyPress += (s, e) =>
            {
                if (_selectedNode == null) return;

                // CTRL+Z = ASCII 26
                if (e.KeyChar == (char)26)
                {
                    e.Handled = true; // verhindert weitere Verarbeitung
                    return;
                }

                // Nur bei echten Zeichen starten
                if (!char.IsControl(e.KeyChar))
                {
                    _undoTimer.Stop();
                    _undoTimer.Start();
                }
            };

            Editor.KeyUp += (s, e) =>
            {
               

                if (e.Control && e.KeyCode == Keys.V)
                {
                    _selectedNode.AddUndo(Editor.Text, Editor.CurrentPosition, Editor.FirstVisibleLine);
                }

            };

            // Ergänze Akkord Shortcuts Kommentar / Uncomment
            KeyDown += (s, e) =>
            {


                if (e.KeyCode == Keys.Enter ||
                    e.KeyCode == Keys.OemPeriod ||
                    e.KeyCode == Keys.OemSemicolon ||
                    e.KeyCode == Keys.OemCloseBrackets ||
                    e.KeyCode == Keys.Delete)
                {
                    _selectedNode.AddUndo(Editor.Text, Editor.CurrentPosition, Editor.FirstVisibleLine);
                    _undoTimer.Stop();
                    return;
                }

                if (e.KeyCode == Keys.Back)
                {
                    _undoTimer.Stop();
                    _undoTimer.Start();
                }





                if (e.Control && e.KeyCode == Keys.Z)
                {
                    if (_selectedNode != null)
                    {
                        Undo undo = _selectedNode.GetUndo();
                        if(undo == null) return;
                        Editor.Text = undo.Text;
                        Editor.FirstVisibleLine = undo.FirstLine;
                        Editor.GotoPosition(undo.Position);
                    }
                }
                
                if (e.Control && e.KeyCode == Keys.K)
                {
                    _awaitingCtrlK = true;
                    _chordTimer.Stop();
                    _chordTimer.Start();
                    e.SuppressKeyPress = true;
                    return;
                }
                if (_awaitingCtrlK && e.Control && e.KeyCode == Keys.C)
                {
                    e.SuppressKeyPress = true;
                    _awaitingCtrlK = false; _chordTimer.Stop();
                    CommentSelection();
                    return;
                }
                if (_awaitingCtrlK && e.Control && e.KeyCode == Keys.U)
                {
                    e.SuppressKeyPress = true;
                    _awaitingCtrlK = false; _chordTimer.Stop();
                    UncommentSelection();
                    return;
                }

            };
            KeyDown += (s, e) =>
            {
                if (e.Control && e.KeyCode == Keys.M)
                {
                    _awaitingCtrlM = true;
                    _chordTimer.Stop();
                    _chordTimer.Start();
                    e.SuppressKeyPress = true;
                    return;
                }
                if (_awaitingCtrlM && e.Control && e.KeyCode == Keys.O)
                {
                    e.SuppressKeyPress = true;
                    _awaitingCtrlM = false; _chordTimer.Stop();
                    CollapseAllInnerBlocksExceptOuter();
                    return;
                }
                if (_awaitingCtrlM && e.Control && e.KeyCode == Keys.L)
                {
                    e.SuppressKeyPress = true;
                    _awaitingCtrlM = false; _chordTimer.Stop();
                    ExpandAllBlocksAtCaret();
                    return;
                }

            };

            // SearchBar einbinden (rechte obere Ecke)
            _searchBar.Visible = false;
            _searchBar.FindNextRequested += (s, e) => ExecuteSearch(next: true);
            _searchBar.CloseRequested += (s, e) => { _searchBar.Visible = false; Editor.Focus(); };
            Controls.Add(_searchBar);
            _searchBar.BringToFront();
            Resize += (_, __) => PositionSearchBar();
            PositionSearchBar();

            // ReplaceBar einbinden (rechts unter SearchBar)
            _replaceBar.Visible = false;
            _replaceBar.FindNextRequested += (s, e) => ReplaceFindNext();
            _replaceBar.ReplaceRequested += (s, e) => ReplaceSingle();
            _replaceBar.ReplaceAllRequested += (s, e) => ReplaceAll();
            _replaceBar.CloseRequested += (s, e) => { _replaceBar.Visible = false; Editor.Focus(); };
            Controls.Add(_replaceBar);
            _replaceBar.BringToFront();

            KeyDown += (s, e) =>
            {
                if (e.Control && e.KeyCode == Keys.H)
                {
                    e.SuppressKeyPress = true;
                    ShowReplaceBar();
                }
            };

            KeyDown += async (s, e) =>
            {
                if (e.Control && e.KeyCode == Keys.F)
                {
                    e.SuppressKeyPress = true;
                    ShowSearchBar();
                }
                else if (e.KeyCode == Keys.F3)
                {
                    e.SuppressKeyPress = true;
                    ExecuteSearch(next: true);
                }
            };

            ApplyLightTheme();
        }
        public void ResetCurrentFile()
        {
            _currentFile = null;
        }

        // UI Invoke Helper
        private void OnUi(Action a)
        {
            if (IsDisposed) return;
            if (InvokeRequired) BeginInvoke(a); else a();
        }
        private static bool IsBrace(int c) => c is '(' or ')' or '[' or ']' or '{' or '}';

        private static readonly string CsKeywords = "abstract as base bool break byte case catch char checked class const continue decimal default delegate do double else enum event explicit extern false finally fixed float for foreach goto if implicit in int interface internal is lock long namespace new null object operator out override params private protected public readonly ref return sbyte sealed short sizeof stackalloc static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using virtual void volatile while var dynamic partial record global alias async await nameof when where yield get set add remove file required scoped nint nuint not and or";

        private static readonly string[] FallbackKeywords = new[] {
            "System","public","private","protected","internal","class","interface","struct","record","void","string","int","var","using","namespace","return","async","await","new","if","else","for","foreach","while","switch","case","break","continue","try","catch","finally","true","false","null","partial","static","readonly","override","virtual","sealed","params","out","ref" };

        // --- Helper (bereinigt) -------------------------------------------------
        private static readonly Regex RxTypeDecl = new(@"\b(class|record|struct|interface)\s+([A-Za-z_][A-ZaZ0-9_]*)", RegexOptions.Compiled);
        private static readonly Regex RxVarDecl = new(@"\b(?:(?:public|private|protected|internal|static|readonly|volatile|const|ref|out|in|unsafe|sealed|new|partial|extern)\s+)*([A-ZaZ_][A-ZaZ0-9_<>,\.?]*)\s+(?<name>[A-ZaZ_][A-ZaZ0-9_]*)\s*(?=[=;,)\r\n])", RegexOptions.Compiled);
        private static readonly Regex RxPropertyDecl = new(@"\b(?:(?:public|private|protected|internal|static|readonly|sealed|new|partial)\s+)*([A-ZaZ_][A-ZaZ0-9_<>,\.?]*)\s+(?<pname>[A-ZaZ_][A-ZaZ0-9_]*)\s*\{", RegexOptions.Compiled);
        private static readonly Regex RxParameter = new(@"[(,]\s*(?:this\s+)?(?:ref|out|in\s+)?[A-Za-z_][A-ZaZ0-9_<>,\.?]*\s+(?<param>[A-ZaZ_][A-ZaZ0-9_]*)\s*(?=,|\)|=)", RegexOptions.Compiled);
        private List<string> ExtractLocalTypeNames(string text)
        {
            var list = new List<string>();
            foreach (Match m in RxTypeDecl.Matches(text)) if (m.Success) list.Add(m.Groups[2].Value);
            return list;
        }
        private HashSet<string> CollectDeclaredIdentifiers(string text, int caret)
        {
            if (caret < text.Length)
                text = text.Substring(0, caret);

            var set = new HashSet<string>(StringComparer.Ordinal);

            foreach (Match m in RxVarDecl.Matches(text))
                if (m.Success)
                    set.Add(m.Groups["name"].Value);

            foreach (Match m in RxPropertyDecl.Matches(text))
                if (m.Success)
                    set.Add(m.Groups["pname"].Value);

            foreach (Match m in RxParameter.Matches(text))
                if (m.Success)
                    set.Add(m.Groups["param"].Value);

            return set;
        }
        private IEnumerable<string> SuggestVariableNames(string typeName)
        {
            var set = new HashSet<string>(StringComparer.Ordinal);
            var tokens = typeName.Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries);
            var merged = string.Concat(tokens);

            if (merged.Length > 0)
                set.Add(char.ToLowerInvariant(merged[0]) + merged.Substring(1));

            if (tokens.Length > 0)
            {
                var first = tokens[0];
                if (first.Length > 0)
                    set.Add(char.ToLowerInvariant(first[0]) + first.Substring(1));

                var last = tokens[tokens.Length - 1];
                if (last.Length > 0)
                    set.Add(char.ToLowerInvariant(last[0]) + last.Substring(1));

                foreach (string t in tokens)
                {
                    if (string.Equals(t, "Page", StringComparison.OrdinalIgnoreCase))
                    {
                        set.Add("page");
                        break;
                    }
                }

                if (tokens.Length > 1 && string.Equals(tokens[0], "Page", StringComparison.OrdinalIgnoreCase))
                    set.Add("page" + last);
            }

            return set;
        }
        private string GetPreviousIdentifier(int position)
        {
            int pos = position - 1; while (pos >= 0 && char.IsWhiteSpace((char)Editor.GetCharAt(pos))) pos--; if (pos < 0) return string.Empty;
            int end = pos; while (pos >= 0) { char ch = (char)Editor.GetCharAt(pos); if (!(char.IsLetterOrDigit(ch) || ch == '_')) break; pos--; }
            int start = pos + 1; return end >= start ? Editor.GetTextRange(start, end - start + 1) : string.Empty;
        }
        private bool IsInMemberAccessContext(int caret)
        {
            if (caret <= 0) return false;
            int pos = caret - 1;
            while (pos >= 0)
            {
                char ch = (char)Editor.GetCharAt(pos);
                if (char.IsLetterOrDigit(ch) || ch == '_') pos--; else break;
            }
            return pos >= 0 && Editor.GetCharAt(pos) == '.';
        }
        private string GetCurrentIdentifierPrefix(int caret)
        {
            if (caret == 0) return string.Empty;
            int pos = caret - 1; while (pos >= 0) { char ch = (char)Editor.GetCharAt(pos); if (!(char.IsLetterOrDigit(ch) || ch == '_')) break; pos--; }
            int start = pos + 1; return Editor.GetTextRange(start, caret - start);
        }
        private async Task TryAddUsingForIdentifierBeforeDotAsync()
        {
            if (_currentFile == null || !_currentFile.EndsWith(".cs") || !_roslyn.IsProjectLoaded) return;
            int caret = Editor.CurrentPosition;
            int dotPos = caret - 1; // just inserted '.'
            if (dotPos <= 0) return;
            int pos = dotPos - 1;
            while (pos >= 0)
            {
                char ch = (char)Editor.GetCharAt(pos);
                if (!(char.IsLetterOrDigit(ch) || ch == '_')) break;
                pos--;
            }
            int start = pos + 1;
            if (start >= dotPos) return;
            string ident = Editor.GetTextRange(start, dotPos - start);
            if (string.IsNullOrWhiteSpace(ident)) return;
            char prev = start > 0 ? (char)Editor.GetCharAt(start - 1) : '\0';
            if (prev == ')') return; // probable method call
            var newText = await _roslyn.AddUsingIfUniqueTypeAsync(_currentFile, Editor.Text, ident);
            if (newText != null && !ReferenceEquals(newText, Editor.Text))
            {
                int oldPos = Editor.CurrentPosition;
                Editor.Text = newText;
                Editor.GotoPosition(Math.Min(oldPos, Editor.TextLength));
            }
        }

        // ---------------- File I/O ----------------
        public async Task LoadBook()
        {
            _roslyn.Reset();
            _roslyn = new RoslynServices();

            tblBuildOutputs.Clear();
            tblBuildOutputs.Clear();


            ProjectTree.BeginUpdate();
            ProjectTree.ImageList = imageList1;
            ProjectTree.Nodes.Clear();


            RootNode = new EditorNode(qbook.Core.ThisBook.Filename)
            {
                ImageIndex = 1
            };

            ProjectTree.Font = new Font("Calibri", 12);
            ProjectTree.Nodes.Add(RootNode);

            string firstFile = null;
            string program = "";

            program += "namespace QB\r\n{\r\n";
            program += "   public static class Program {\r\n";

            string tempPath = Path.GetTempPath();


            RootNode.FilePath = Path.Combine(tempPath, Path.GetRandomFileName());

            // string uri = @"c:\temp\code";

            Debug.WriteLine("Using Temp Directory " + RootNode.FilePath);

            Directory.CreateDirectory(RootNode.FilePath);
            Directory.CreateDirectory(Path.Combine(RootNode.FilePath, "dlls"));

            int pageCount = -1;
            foreach (oPage page in qbook.Core.ActualMain.Objects.Where(item => item is oPage))
            {
                pageCount++;
                string code = page.CsCode;

                int index = code.IndexOf("public class");
                Debug.WriteLine("index= " + index);
                string insertText = "\r\nnamespace class_" + page.Name + "\r\n" + "{" + "\r\n";
                code = code.Insert(index - 1, insertText);
                code += "\r\n}";

                string className = "class_" + page.Name + ".@class_" + page.Name;
                program += "   public static " + className + " " + page.Name + " { get;} = new " + className + "();\r\n";
                Directory.CreateDirectory(Path.Combine(RootNode.FilePath, pageCount + "_" + page.Name));

                File.WriteAllText(Path.Combine(RootNode.FilePath, pageCount + "_" + page.Name, "0_class_" + page.Name + ".cs"), code);

                EditorNode pageNode = new EditorNode(page, Path.Combine(RootNode.FilePath, pageCount + "_" + page.Name, "0_class_" + page.Name + ".cs"), EditorNode.NodeType.Page);
                pageNode.Active = true;
                ProjectTree.Nodes[0].Nodes.Add(pageNode);

                if (firstFile == null)
                    firstFile = Path.Combine(RootNode.FilePath, pageCount + "_" + page.Name, "0_class_" + page.Name + ".cs");

                string global = "global using static QB.Program;\r\n";
                File.WriteAllText(Path.Combine(RootNode.FilePath, "GlobalUsing.cs"), global);
                var lines = code.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);

                var usings = lines
                .TakeWhile(l => !l.TrimStart().StartsWith("public class"))
                .Where(l => l.TrimStart().StartsWith("using"))
                .ToList();

                int subCount = 0;

                List<string> includes = ExtractIncludes(page.CsCode);
                foreach (var subClass in page.CsCodeExtra)
                {
                    subCount++;
                    string sub = "";

                    foreach (string use in usings)
                    {
                        sub += $"{use}\r\n";
                    }

                    sub += "\r\nnamespace class_" + page.Name + "\r\n{\r\n\r\n";
                    sub += subClass.Value;
                    sub += "\r\n}";

                    string file = Path.Combine(RootNode.FilePath, pageCount + "_" + page.Name, subCount + "_" + subClass.Key + ".cs");

                    File.WriteAllText(file, sub);
                    EditorNode subNode = new EditorNode(page, file, EditorNode.NodeType.SubCode, subClass.Key, pageNode);


                    subNode.Active = includes.Contains(subClass.Key) ? true : false;
                    subNode.ImageIndex = subNode.Active ? 3 : 5;

                    ProjectTree.Nodes[0].Nodes[pageCount].Nodes.Add(subNode);
                }

            }

            program += "   }\r\n}";
            File.WriteAllText(Path.Combine(RootNode.FilePath, "Program.cs"), program);

            string root = CsprojGenerator.GetSolutionDirectory();

            string csprojXml = GenerateCsprojWithAbsolutePaths(RootNode.FilePath);
            string projectFile = Path.Combine(RootNode.FilePath, "Generated.csproj");
            File.WriteAllText(projectFile, csprojXml);

            QB.Logger.Info("Loading Project " + projectFile);

            ProjectTree.BeginInvoke((Action)(() =>
            {
                string[] excudeDir = { "bin", "obj", "dlls" };
                string[] excudeFiles = { "*.csproj", "GlobalUsing.cs", "Program.cs" };


                if (File.Exists(projectFile))
                {
                    _projectRoot = Path.GetDirectoryName(projectFile);
                    QB.Logger.Info("Project Root " + _projectRoot);

                    _ = _roslyn.LoadProjectAsync(projectFile).ContinueWith(async t =>
                    {
                        // await LoadProjectTree(excudeDir, excudeFiles);

                        if (firstFile != null)
                        {
                            // Lade den Text der Datei
                            var text = File.ReadAllText(firstFile);
                            await _roslyn.UpdateOpenDocumentAsync(firstFile, text);
                            await _roslyn.GetCompletionsAsync(firstFile, text, 0);
                        }
                    });
                }

            }));



            Core.ProgramWorkingDir = RootNode.FilePath;

            QB.Logger.Info("Using Working Directory " + Core.ProgramWorkingDir);

            ProjectTree.EndUpdate();
        }
        private void SaveFile() 
        { 
            if (string.IsNullOrEmpty(_currentFile))
            { 
                SaveFileAs(); 
                return; 
            } 
            File.WriteAllText(_currentFile!, Editor.Text); 
        }
        private void SaveFileAs()
        { using var sfd = new SaveFileDialog { Filter = "C# files|*.cs|All files|*.*" }; if (sfd.ShowDialog(this) == DialogResult.OK) { _currentFile = sfd.FileName; SaveFile(); } }
        private void OpenFile(string path)
        {
            _currentFile = path;
            Editor.Text = File.ReadAllText(_currentFile);
            _selectedNode.AddUndo(Editor.Text, 1, 1);

            if (_selectedNode == null) return;
            if (!_selectedNode.Active) return;

            Text = $"AmiumCode - {Path.GetFileName(_currentFile)}";
            _ = _roslyn.UpdateOpenDocumentAsync(_currentFile, Editor.Text);

            var csproj = FindCsprojNear(_currentFile);
            if (csproj != null)
                _ = _roslyn.LoadProjectAsync(csproj);
            InitializeFolding();
            _ = RefreshSemanticOverlaysAsync();
        }
        private string? FindCsprojNear(string filePath)
        { var dir = new DirectoryInfo(Path.GetDirectoryName(filePath)!); while (dir != null) { var cand = dir.GetFiles("*.csproj").FirstOrDefault(); if (cand != null) return cand.FullName; dir = dir.Parent; } return null; }
        public string GenerateCsprojWithAbsolutePaths(string uri)
        {
            string root = AppDomain.CurrentDomain.BaseDirectory;
            QB.Logger.Debug("Generating csproj for '" + uri + "'");
            QB.Logger.Debug("Solution root is '" + root + "'");
            string projectRoot = uri;
            string projectDlls = Path.Combine(projectRoot, "dlls");
            string baseDir = Path.Combine(root, "libs");

            var dllFiles = Directory.GetFiles(baseDir, "*.dll")
                .Concat(Directory.Exists(projectDlls) ? Directory.GetFiles(projectDlls, "*.dll") : Array.Empty<string>())
                .ToArray();

            string[] exclude = { "Microsoft.CodeAnalysis" };

            var referenceItems = dllFiles
                .Where(path =>
                {
                    string fileName = Path.GetFileNameWithoutExtension(path);
                    return !exclude.Any(prefix => fileName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));
                })
                .Select(path =>
                {
                    string fileName = Path.GetFileNameWithoutExtension(path);
                    return $@"
    <Reference Include=""{fileName}"">
      <HintPath>{path}</HintPath>
    </Reference>";
                });

            // WICHTIG: Alle C#-Dateien wie in deinem Build einbinden
            // (wildcards decken Unterordner ab)
            var compileItems = $@"
    <Compile Include=""{uri}\**\*.cs"" />";

            return $@"
<Project Sdk=""Microsoft.NET.Sdk"">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net9.0-windows</TargetFramework>
    <UseWindowsForms>true</UseWindowsForms>
    <EnableDefaultItems>false</EnableDefaultItems>
  </PropertyGroup>

  <ItemGroup>
{compileItems}
  </ItemGroup>

  <ItemGroup>
{string.Join("\n", referenceItems)}
  </ItemGroup>
</Project>";
        }

        // ---------------- Check Code ----------------

        bool buildError = false;
        async Task CheckCode()
        {

            foreach (EditorNode page in ProjectTree.Nodes[0].Nodes)
            {

                await BuildRunDiagnosticsAsync(page);
                foreach (EditorNode subcode in page.Nodes)
                {
                    await BuildRunDiagnosticsAsync(subcode);
                }
            }
        }
        private async Task BuildRunDiagnosticsAsync(EditorNode node)
        {

            try
            {
                if (!node.Active) return;

                string pageName = "";
                string nodeName = "";

                _selectedNode.ForeColor = ProjectTree.ForeColor;
                _selectedNode = node;
                _selectedNode.ForeColor = _currentTheme == EditorTheme.Dark ? Color.Plum : Color.Purple;
                _currentFile = node.FilePath;
                Editor.Text = File.ReadAllText(node.FilePath);
                node.Expand();
                if (node.Type == EditorNode.NodeType.Page)
                {
                    //  MessageBox.Show($"Build diagnostics for {node.Text} Type {node.Type}");
                    pageName = node.Text;
                }
                else
                {
                    //  MessageBox.Show($"Build diagnostics for {node.PageNode.Text} / {node.Text} Type {node.Type}");
                    pageName = node.PageNode.Text;
                    nodeName = node.Text;
                }

                string buffer = Editor.Text;
                var collected = new List<Diagnostic>();

                if (_roslyn.IsProjectLoaded)
                {
                    await _roslyn.UpdateOpenDocumentAsync(node.FilePath, buffer);
                    var doc = _roslyn.GetDocument(node.FilePath);
                    if (doc != null)
                    {
                        var tree = await doc.GetSyntaxTreeAsync();
                        if (tree != null) collected.AddRange(tree.GetDiagnostics());

                        var model = await doc.GetSemanticModelAsync();
                        if (model != null) collected.AddRange(model.GetDiagnostics());

                        var comp = await doc.Project.GetCompilationAsync();
                        if (comp != null && tree != null)
                        {
                            collected.AddRange(comp.GetDiagnostics()
                                .Where(d => d.Location.IsInSource && d.Location.SourceTree == tree));
                        }
                    }
                }
                else
                {
                    // Fallback: eigene Compilation mit Basis-Referenzen erstellen
                    var tree = CSharpSyntaxTree.ParseText(buffer);
                    var refs = GetBasicMetadataReferences();
                    var compilation = CSharpCompilation.Create("Live",
                        new[] { tree },
                        refs,
                        new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
                    collected.AddRange(compilation.GetDiagnostics());
                }

                var final = collected
                    .Where(d => d.Severity == DiagnosticSeverity.Error && !d.IsSuppressed && d.Location.IsInSource)
                    .GroupBy(d => (d.Id, d.Location.SourceSpan.Start, d.Location.SourceSpan.Length))
                    .Select(g => g.First())
                    .ToList();

                var errorSpansTmp = new List<(int start, int length, string message)>();
                foreach (var d in final)
                {
                    var (s, l) = GetNiceErrorRange(d);
                    if (l <= 0) l = 1;
                    s = Math.Max(0, Math.Min(s, Editor.TextLength));
                    l = Math.Max(1, Math.Min(l, Editor.TextLength - s));
                    errorSpansTmp.Add((s, l, d.GetMessage(CultureInfo.GetCultureInfo("en-US"))));
                }
                foreach (var tup in errorSpansTmp)
                {
                    string pos = tup.start.ToString();
                    TableBuildAdd(pageName, nodeName, pos, tup.length, "Error", tup.message, node);
                    buildError = true;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Diagnostics error: " + ex.Message);
            }
        }
        public async Task HandleRebuildAsync()
        {
            TableBuildClear();
            //   SaveCode();
            SetStatusText("Rebuild ...");
            await Task.Yield();
            buildError = false;
            await CheckCode();
            MessageBox.Show("Builderror " + buildError);
            if (buildError)
            {
                MessageBox.Show("Your code contains errors. Please correct them before proceeding.");
                return;
            }
            // await RebuildCodeAllAsync();

        }

        // ---------------- Roslyn wiring / Completion ----------------
        private async Task PushBufferToRoslynAsync() 
        { 
           
            
            if (_currentFile == null || !_currentFile.EndsWith(".cs")) return; 
            await _roslyn.UpdateOpenDocumentAsync(_currentFile, Editor.Text); 
        }
        private async Task ShowCompletionAsync()
        {
            if (_currentFile == null || !_currentFile.EndsWith(".cs")) return;

         

                int caret = Editor.CurrentPosition;
            string prefix = GetCurrentIdentifierPrefix(caret);
            bool afterDot = caret > 0 && Editor.GetCharAt(caret - 1) == '.';
            bool inMemberAccess = !afterDot && IsInMemberAccessContext(caret);
            CompletionItem[] roslynItems = Array.Empty<CompletionItem>(); int roslynSpanStart = caret;
            if (_roslyn.IsProjectLoaded)
            { 
                try 
                {  
                   
                    (roslynItems, roslynSpanStart) = await _roslyn.GetCompletionsAsync(_currentFile, Editor.Text, caret); 
                } 
                catch 
                { 
                    roslynItems = Array.Empty<CompletionItem>();
                    roslynSpanStart = caret; 
                } 
            }
            if (roslynItems.Length == 0 && prefix.Length > 0) roslynSpanStart = caret - prefix.Length;
            var suggestions = new HashSet<string>(StringComparer.Ordinal);
            foreach (var it in roslynItems) if (!string.IsNullOrWhiteSpace(it.DisplayText)) suggestions.Add(it.DisplayText);
            if (afterDot || inMemberAccess)
            {
                if (prefix.Length > 0) suggestions = suggestions.Where(s => s.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).ToHashSet(StringComparer.Ordinal);
                if (suggestions.Count == 0) return;
                var orderedMA = suggestions.OrderBy(s => s, StringComparer.OrdinalIgnoreCase).ToArray();
                var listMA = string.Join(" ", orderedMA);
                int replaceLenMA = prefix.Length; // nutze Prefix-Länge für stabile inkrementelle Filterung
                if (replaceLenMA < 0) replaceLenMA = 0;
                Editor.AutoCSeparator = ' '; Editor.AutoCStops("()[]{}.:,;+-*/%=!<>?&|^~ "); Editor.AutoCSetFillUps("()[]{}.;, "); Editor.AutoCShow(replaceLenMA, listMA); return;
            }
            var localTypes = ExtractLocalTypeNames(Editor.Text);
            foreach (var t in localTypes) if (prefix.Length == 0 || t.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) suggestions.Add(t);
            if (prefix.Length > 0)
            {
                foreach (var id in CollectDeclaredIdentifiers(Editor.Text, caret)) if (id.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) suggestions.Add(id);
                foreach (var k in FallbackKeywords) if (k.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) suggestions.Add(k);
                int prefixStart = caret - prefix.Length; var prev = GetPreviousIdentifier(prefixStart);
                if (!string.IsNullOrEmpty(prev) && (localTypes.Contains(prev) || suggestions.Contains(prev)))
                    foreach (var vn in SuggestVariableNames(prev)) if (vn.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) suggestions.Add(vn);
                if (_roslyn.IsProjectLoaded)
                {
                    // directe LookupSymbols-Auswertung
                    var members = await _roslyn.LookupInstanceMemberNamesAsync(_currentFile, Editor.Text, caret);
                    foreach (var m in members) if (m.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) suggestions.Add(m);
                    // hierarchische enumeration als Fallback (stellt sicher dass z.B. 'View' auftaucht)
                    var hierarchyMembers = await _roslyn.EnumerateHierarchyInstanceMembersAsync(_currentFile, Editor.Text, caret);
                    foreach (var hm in hierarchyMembers) if (hm.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) suggestions.Add(hm);
                }
                if (_roslyn.IsProjectLoaded && prefix.Length >= 1)
                {
                    var projectTypes = await _roslyn.FindTypeCandidatesAsync(_currentFile, Editor.Text, prefix);
                    foreach (var t in projectTypes)
                    {
                        if (!suggestions.Contains(t)) suggestions.Add(t);
                    }
                }
            }
            if (suggestions.Count == 0)
            {
                // Keep existing list if still active (avoid flicker when temporarily empty)
                if (Editor.AutoCActive) return; else return; // nothing to show
            }
            // determine anchor for replaceLen (scan back over identifier)
            int anchor = caret;
            while (anchor > 0)
            {
                char ch = (char)Editor.GetCharAt(anchor - 1);
                if (char.IsLetterOrDigit(ch) || ch == '_') anchor--; else break;
            }
            var ordered = suggestions.OrderBy(s => (char.IsUpper(s.FirstOrDefault()) ? "1" : "2") + s, StringComparer.OrdinalIgnoreCase).ToArray();
            var list = string.Join(" ", ordered);
            int replaceLen = caret - anchor;
            if (replaceLen < 0) replaceLen = 0;
            if (replaceLen > prefix.Length) replaceLen = prefix.Length; // safety
            Editor.AutoCSeparator = ' ';
            Editor.AutoCStops("()[]{}.:,;+-*/%=!<>?&|^~ ");
            Editor.AutoCSetFillUps("()[]{}.;, ");
            Editor.AutoCShow(replaceLen, list);
        }
        private async Task GoToDefinitionAsync()
        {
            if (_currentFile == null || !_currentFile.EndsWith(".cs")) return; 
            var caret = Editor.CurrentPosition;
            var loc = await _roslyn.GoToDefinitionAsync(_currentFile, Editor.Text, caret); 
            if (loc == null) return;
            var (filePath, line, column) = loc.Value;
            if (!string.Equals(_currentFile, filePath, StringComparison.OrdinalIgnoreCase)) 
            { 
                _currentFile = filePath;
                Editor.Text = File.ReadAllText(_currentFile); 
                Text = $"AmiumCode - {Path.GetFileName(_currentFile)}"; 
            }
            var pos = GetPositionFromLineColumn(Editor, line, column); 
            Editor.GotoPosition(pos); 
            Editor.ScrollCaret();
        }
        public static string ShowReplaceDialog(string prompt, string title, string defaultValue = "")
        {
            Form inputForm = new Form()
            {
                Width = 400,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = title,
                StartPosition = FormStartPosition.CenterScreen
            };

            System.Windows.Forms.Label textLabel = new System.Windows.Forms.Label() { Left = 10, Top = 20, Text = prompt, AutoSize = true };
            System.Windows.Forms.TextBox textBox = new System.Windows.Forms.TextBox() { Left = 10, Top = 50, Width = 360, Text = defaultValue };
            System.Windows.Forms.Button confirmation = new System.Windows.Forms.Button() { Text = "OK", Left = 290, Width = 80, Top = 80, DialogResult = System.Windows.Forms.DialogResult.OK };

            inputForm.Controls.Add(textLabel);
            inputForm.Controls.Add(textBox);
            inputForm.Controls.Add(confirmation);
            inputForm.AcceptButton = confirmation;

            return inputForm.ShowDialog() == DialogResult.OK ? textBox.Text : null;
        }
        private async Task RenameSymbolAsync()
        {
            if (_currentFile == null || !_currentFile.EndsWith(".cs")) return;
            if (!_roslyn.IsProjectLoaded)
            {
                MessageBox.Show(this, "Project not loaded – open a .csproj based file first.", "Rename", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int firstLine = Editor.FirstVisibleLine;

            // Caret & Auswahl sichern (Positions-/Längenänderungen berücksichtigen wir später)
            int caretBefore = Editor.CurrentPosition;
            int selStartBefore = Editor.SelectionStart;
            int selEndBefore = Editor.SelectionEnd;

            // Neuen Namen abfragen
            var input = ShowReplaceDialog("Neuer Name:", "Rename Symbol", "NewName");
            if (string.IsNullOrWhiteSpace(input)) return;
            string newName = input.Trim();

            // Roslyn-Rename (liefert evtl. mehrere geänderte Dateien)
            var renameResult = await _roslyn.RenameSymbolAsync(_currentFile, Editor.Text, caretBefore, newName);
            if (renameResult == null || renameResult.Count == 0)
            {
                MessageBox.Show(this, "Rename failed (symbol not found or no changes).", "Rename", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Aktuelle Datei im Editor aktualisieren (Undo-Block)
            if (renameResult.TryGetValue(_currentFile, out var newText) && !string.Equals(newText, Editor.Text, StringComparison.Ordinal))
            {
                Editor.BeginUndoAction();
                try
                {
                    Editor.TargetStart = 0;
                    Editor.TargetEnd = Editor.TextLength;
                    Editor.ReplaceTarget(newText);
                }
                finally { Editor.EndUndoAction(); }
            }

            // Alle betroffenen Dateien auf Platte schreiben (best effort)
            foreach (var kv in renameResult)
            {
                try { File.WriteAllText(kv.Key, kv.Value); } catch { /* Datei könnte read-only sein o.ä. */ }
            }

            // Caret/Auswahl wieder in gültigen Bereich bringen
            int newLen = Editor.TextLength;
            int newCaret = Math.Min(caretBefore, newLen);
            int newSelStart = Math.Min(selStartBefore, newLen);
            int newSelEnd = Math.Min(selEndBefore, newLen);


            // Semantisches Re-Rendering (kann Scrollposition beeinflussen)
            await RefreshSemanticOverlaysAsync();
            await RefreshDiagnosticsAsync();

            Editor.Lines[firstLine].Goto();
            Editor.SetSelection(newSelEnd, newSelStart);
            Editor.GotoPosition(newCaret);

        }

        private sealed class RoslynFacade
        {
            public bool IsProjectLoaded => true;
            public Task<System.Collections.Generic.Dictionary<string, string>> RenameSymbolAsync(string file, string text, int caretBefore, string newName)
                => Task.FromResult(new System.Collections.Generic.Dictionary<string, string>());
        }

        private static int GetPositionFromLineColumn(Scintilla ed, int line, int column) => ed.Lines[line].Position + column;

        //=========== ProjectTree =========== 

        EditorNode _selectedNode;
        private void UpdateAllNodes(System.Windows.Forms.TreeView tree, Color color, int nodeLevel, int newIndex)
        {
            foreach (EditorNode node in tree.Nodes)
            {
                UpdateNodeByLevelRecursive(node, color, nodeLevel, newIndex);
            }
        }
        private void UpdateNodeByLevelRecursive(EditorNode node, Color color, int oldIndex, int newIndex)
        {
                node.ForeColor = color;
                node.ImageIndex = node.ImageIndex == oldIndex ? newIndex : node.ImageIndex;
                node.SelectedImageIndex = newIndex;
 
            foreach (EditorNode child in node.Nodes)
            {
                UpdateNodeByLevelRecursive(child, color, oldIndex, newIndex);
            }
        }

        EditorNode _clickedNode;
        private async void TreeProject_NodeMouseClick(object? sender, TreeNodeMouseClickEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                OpendNode(e.Node as EditorNode);
                UpdateTabs();
            }
        
            if (e.Button == MouseButtons.Right)
            {
                _clickedNode = e.Node as EditorNode;

                if (_clickedNode.Active)
                {
                    toolStripMenuIncludeCode.Text = "Exclude Code";
                }
                else
                {
                    toolStripMenuIncludeCode.Text = "Include Code";
                }
                  

                oPage page = FindPageByName(Regex.Replace(_selectedNode.Text, @"^[^_]*_", ""));
                if (page != null)
                {
                    hidePageToolStripMenuItem.Text = page.Hidden ? "Show Page" : "Hide Page";
                }

                var clickedNode = ((System.Windows.Forms.TreeView)sender).GetNodeAt(new Point(e.X, e.Y));
                if (e.Node.Level == 0)
                {
                    addPageBeforeToolStripMenuItem.Visible = false;
                    addPageAfterToolStripMenuItem.Visible = false;
                    hidePageToolStripMenuItem.Visible = false;
                    addSubCodeToolStripMenuItem.Visible = false;
                    deleteStripMenuItem.Visible = false;
                    toolStripMenuOpenWorkspace.Visible = true;
                    renamePageToolStripMenuItem.Visible = false;
                    renameCodeToolStripMenuItem.Visible = false;
                    toolStripMenuIncludeCode.Visible = false;
                }
                if (e.Node.Level == 1)
                {
                    addPageBeforeToolStripMenuItem.Visible = true;
                    addPageAfterToolStripMenuItem.Visible = true;
                    hidePageToolStripMenuItem.Visible = true;
                    addSubCodeToolStripMenuItem.Visible = true;
                    renamePageToolStripMenuItem.Visible = false;
                    deleteStripMenuItem.Visible = false;
                    toolStripMenuOpenWorkspace.Visible = false;
                    renameCodeToolStripMenuItem.Visible = false;
                    toolStripMenuIncludeCode.Visible = false;
                }

                if (e.Node.Level == 2)
                {
                    addPageBeforeToolStripMenuItem.Visible = false;
                    addPageAfterToolStripMenuItem.Visible = false;
                    hidePageToolStripMenuItem.Visible = false;
                    addSubCodeToolStripMenuItem.Visible = false;
                    toolStripMenuOpenWorkspace.Visible = false;
                    toolStripMenuIncludeCode.Visible = true;

                    renamePageToolStripMenuItem.Visible = false;

                    if (_selectedNode.Text.StartsWith("0_"))
                    {
                        renameCodeToolStripMenuItem.Visible = false;
                        deleteStripMenuItem.Visible = false;
                    }
                    else
                    {
                        renameCodeToolStripMenuItem.Visible = true;
                        deleteStripMenuItem.Visible = true;
                    }


                }
                contextMenuTreeView.Show(ProjectTree, e.Location);
            }

           

        }
        private void UpdateMethodes()
        {
            tblMethodes.Clear();

            // Editor-Text in Zeilen zerlegen
            var lines = Editor.Text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);

            // Regex für Methoden
            var methodPattern = new Regex(@"\b(public|private|protected|internal|static|async)?\s+(?:[\w<>]+\s+)+(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*\(.*\)\s*(\{|=>)");

            // Regex für Klassen
            var classPattern = new Regex(@"\b(public|private|protected|internal)?\s*(partial\s+)?class\s+(?<name>[A-Za-z_][A-Za-z0-9_]*)");

            for (int i = 0; i < lines.Length; i++)
            {
                var line = lines[i];

                // Methoden suchen
                var methodMatch = methodPattern.Match(line);
                if (methodMatch.Success)
                {
                    string methodName = methodMatch.Groups["name"].Value;
                    DataRow row = tblMethodes.NewRow();
                    row["Row"] = i + 1;
                    row["Name"] = "[M] " + methodName;
                    tblMethodes.Rows.Add(row);
                }

                // Klassen suchen
                var classMatch = classPattern.Match(line);
                if (classMatch.Success)
                {
                    string className = classMatch.Groups["name"].Value;
                    DataRow row = tblMethodes.NewRow();
                    row["Row"] = i + 1;
                    row["Name"] = "[C] " + className;
                    tblMethodes.Rows.Add(row);
                }
            }

            gridViewMethodes.ClearSelection();
        }

        private System.Windows.Forms.Timer debounceTimer;
        private void Editor_KeyDown(object sender, KeyEventArgs e)
        {
            debounceTimer?.Stop();
            debounceTimer = new System.Windows.Forms.Timer();
            debounceTimer.Interval = 1000;
            debounceTimer.Tick += (s, args) =>
            {
                debounceTimer.Stop();
                UpdateMethodes();
            };
            debounceTimer.Start();
        }
        private oPage FindPageByName(string name)
        {
            Debug.WriteLine("Searching oPage '" + name + "'");
            if (string.IsNullOrEmpty(name)) return null;
            if (qbook.Core.ThisBook == null) return null;
            foreach (oPage page in qbook.Core.ActualMain.Objects.Where(item => item is oPage))
                if (string.Equals(page.Name, name, StringComparison.OrdinalIgnoreCase))
                    return page;
            return null;
        }
        private void InitializeFolding()
        {
            const int MARGIN_FOLD = 2;
            Editor.SetProperty("fold", "1");
            Editor.SetProperty("fold.compact", "1");
            Editor.SetProperty("fold.preprocessor", "1");
            Editor.Margins[MARGIN_FOLD].Type = MarginType.Symbol;
            Editor.Margins[MARGIN_FOLD].Sensitive = true;
            Editor.Margins[MARGIN_FOLD].Mask = Marker.MaskFolders;
            Editor.Margins[MARGIN_FOLD].Width = 16;
            Editor.Markers[Marker.Folder].Symbol = MarkerSymbol.Arrow;
            Editor.Markers[Marker.FolderOpen].Symbol = MarkerSymbol.ArrowDown;
            Editor.Markers[Marker.FolderSub].Symbol = MarkerSymbol.VLine;
            Editor.Markers[Marker.FolderTail].Symbol = MarkerSymbol.LCorner;
            Editor.Markers[Marker.FolderMidTail].Symbol = MarkerSymbol.TCorner;
            Editor.Markers[Marker.FolderEnd].Symbol = MarkerSymbol.Arrow;
            Editor.Markers[Marker.FolderOpenMid].Symbol = MarkerSymbol.ArrowDown;

            int[] folderMarkers = new[] {
            Marker.Folder,
            Marker.FolderOpen,
            Marker.FolderEnd,
            Marker.FolderOpenMid,
            Marker.FolderMidTail,
            Marker.FolderSub,
            Marker.FolderTail
            };

            var fore = Color.FromArgb(0x60, 0x60, 0x60);
            var back = Color.FromArgb(0xE0, 0xE0, 0xE0);

            if (_currentTheme == EditorTheme.Dark)
            {
                fore = Color.DarkGray;
                back = Color.DarkGray;
            }
            else
            {
                fore = Color.DarkGray;
                back = Color.DarkGray;
            }


            foreach (var i in folderMarkers)
            {
                Editor.Markers[i].SetForeColor(fore);
                Editor.Markers[i].SetBackColor(back);
            }

            Editor.AutomaticFold = AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change;
        }

        // Semantic Highlighting
        private async Task RefreshSemanticOverlaysAsync()
        {
            if(_selectedNode == null) return;
            if (_currentFile == null || !_selectedNode.Active) return;
            if (!_roslyn.IsProjectLoaded) return; // Roslyn noch nicht bereit
            if (Editor.TextLength > 500_000) return; // große Dateien überspringen
            try
            {
                await _roslyn.UpdateOpenDocumentAsync(_currentFile, Editor.Text);
                var doc = _roslyn.GetDocument(_currentFile);
                if (doc == null) return;
                var text = await doc.GetTextAsync();
                var span = new TextSpan(0, text.Length);
                var classified = await Classifier.GetClassifiedSpansAsync(doc, span);

                var buckets = new Dictionary<int, List<(int s, int l)>>
                {
                    [2] = new(), // Methoden
                    [3] = new(), // Klassen / Records
                    [4] = new(), // Interfaces
                    [5] = new(), // Structs
                    [6] = new(), // Enums
                    [7] = new(), // Delegates
                    [8] = new(), // Properties
                    [9] = new(), // Fields
                    [10] = new(), // Keywords
                    [11] = new(), // Numbers
                    [12] = new(), // Strings / Chars
                    [13] = new(), // Comments
                    [14] = new(), // Commands (if/while/return)
                    [15] = new(), // NamespaceName
                };

                var map = new Dictionary<string, int>(StringComparer.Ordinal)
                {
                    [ClassificationTypeNames.MethodName] = 2,
                    [ClassificationTypeNames.ExtensionMethodName] = 2,
                    [ClassificationTypeNames.ClassName] = 3,
                    ["record class name"] = 3, // falls Roslyn andere Klassifikation liefert
                    [ClassificationTypeNames.InterfaceName] = 4,
                    [ClassificationTypeNames.StructName] = 5,
                    [ClassificationTypeNames.EnumName] = 6,
                    [ClassificationTypeNames.DelegateName] = 7,
                    [ClassificationTypeNames.PropertyName] = 8,
                    [ClassificationTypeNames.FieldName] = 9,
                    [ClassificationTypeNames.Keyword] = 10,
                    [ClassificationTypeNames.ControlKeyword] = 14, // <— neu: sorgt dafür, dass if/while/return gefärbt werden
                    [ClassificationTypeNames.PreprocessorKeyword] = 14,
                    [ClassificationTypeNames.NumericLiteral] = 11,
                    [ClassificationTypeNames.StringLiteral] = 12,
                    [ClassificationTypeNames.VerbatimStringLiteral] = 12,
                    [ClassificationTypeNames.Comment] = 13,
                    [ClassificationTypeNames.XmlDocCommentText] = 13,
                    [ClassificationTypeNames.NamespaceName] = 15

                };

                int docLen = Editor.TextLength;
                const int maxPerBucket = 4000;
                foreach (var c in classified)
                {
                    if (!map.TryGetValue(c.ClassificationType, out int ind)) continue;
                    int start = Math.Max(0, Math.Min(c.TextSpan.Start, docLen));
                    int len = Math.Max(0, Math.Min(c.TextSpan.Length, docLen - start));
                    if (len == 0) continue;
                    var list = buckets[ind];
                    if (list.Count < maxPerBucket)
                        list.Add((start, len));
                }

                OnUi(() =>
                {
                    foreach (var ind in buckets.Keys)
                    {
                        Editor.IndicatorCurrent = ind;
                        Editor.IndicatorClearRange(0, docLen);
                    }
                    foreach (KeyValuePair<int, List<(int s, int l)>> kvp in buckets)
                    {
                        int ind = kvp.Key;
                        List<(int s, int l)> list = kvp.Value;

                        if (list.Count == 0) continue;
                        Editor.IndicatorCurrent = ind;
                        foreach (var (s, l) in list)
                            Editor.IndicatorFillRange(s, l);
                    }
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Semantic overlay error: " + ex.Message);
            }
        }
        private async Task RefreshDiagnosticsAsync()
        {
           if(_selectedNode == null) return;
            if (_currentFile == null || !_selectedNode.Active) return;
            try
            {
                string buffer = Editor.Text;
                var collected = new List<Diagnostic>();

                if (_roslyn.IsProjectLoaded)
                {
                    await _roslyn.UpdateOpenDocumentAsync(_currentFile, buffer);
                    var doc = _roslyn.GetDocument(_currentFile);
                    if (doc != null)
                    {
                        var tree = await doc.GetSyntaxTreeAsync();
                        if (tree != null) collected.AddRange(tree.GetDiagnostics());

                        var model = await doc.GetSemanticModelAsync();
                        if (model != null) collected.AddRange(model.GetDiagnostics());

                        var comp = await doc.Project.GetCompilationAsync();
                        if (comp != null && tree != null)
                        {
                            collected.AddRange(comp.GetDiagnostics()
                                .Where(d => d.Location.IsInSource && d.Location.SourceTree == tree));
                        }
                    }
                }
                else
                {
                    // Fallback: eigene Compilation mit Basis-Referenzen erstellen
                    var tree = CSharpSyntaxTree.ParseText(buffer);
                    var refs = GetBasicMetadataReferences();
                    var compilation = CSharpCompilation.Create("Live",
                        new[] { tree },
                        refs,
                        new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
                    collected.AddRange(compilation.GetDiagnostics());
                }

                var final = collected
                    .Where(d => d.Severity == DiagnosticSeverity.Error && !d.IsSuppressed && d.Location.IsInSource)
                    .GroupBy(d => (d.Id, d.Location.SourceSpan.Start, d.Location.SourceSpan.Length))
                    .Select(g => g.First())
                    .ToList();

                var errorSpansTmp = new List<(int start, int length, string message)>();
                foreach (var d in final)
                {
                    var (s, l) = GetNiceErrorRange(d);
                    if (l <= 0) l = 1;
                    s = Math.Max(0, Math.Min(s, Editor.TextLength));
                    l = Math.Max(1, Math.Min(l, Editor.TextLength - s));
                    errorSpansTmp.Add((s, l, d.GetMessage(CultureInfo.GetCultureInfo("en-US"))));
                }

                OnUi(() =>
                {
                    Editor.IndicatorCurrent = 0;
                    Editor.IndicatorClearRange(0, Editor.TextLength);

                    TableOutputClear();
                    int errorCount = 1;
                    foreach (var tup in errorSpansTmp)
                    {
                        string pos = tup.start.ToString();
                        TableOutputAdd(errorCount++, pos, tup.length, "Error", tup.message);
                        Editor.IndicatorFillRange(tup.start, tup.length);

                    }
                    dataGridOutput.ClearSelection();
                    _errorSpans = errorSpansTmp;
                    _currentDiagnostics.Clear();
                    _currentDiagnostics.AddRange(final);
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Diagnostics error: " + ex.Message);
            }
        }

        // Hilfsfunktionen für ansehnliche Fehlerspannen
        private (int start, int len) GetNiceErrorRange(Diagnostic d)
        {
            var span = d.Location.SourceSpan;
            int docLen = Editor.TextLength;

            // Spezieller Fall fehlendes Semikolon
            if (d.Id == "CS1002") // ; expected
            {
                if (TryGetMissingSemicolonRange(span.Start, out int s, out int l)) return (s, l);
            }

            // Normale Wort-Umrandung
            int s1 = Editor.WordStartPosition(Math.Max(0, span.Start), true);
            int e1 = Editor.WordEndPosition(Math.Min(docLen, span.Start + Math.Max(1, span.Length)), true);
            if (e1 > s1) return (s1, Math.Min(docLen - s1, e1 - s1));

            // Rückwärts zum nächsten Token
            int p = Math.Max(0, Math.Min(docLen - 1, span.Start));
            string txt = Editor.Text;
            while (p > 0 && char.IsWhiteSpace(txt[p])) p--;
            s1 = Editor.WordStartPosition(p, true);
            e1 = Editor.WordEndPosition(p, true);
            if (e1 > s1) return (s1, e1 - s1);

            // Fallback: einzelnes Zeichen
            int start = Math.Max(0, Math.Min(span.Start, docLen - 1));
            return (start, 1);
        }
        private bool TryGetMissingSemicolonRange(int pos, out int start, out int len)
        {
            int docLen = Editor.TextLength;
            string txt = Editor.Text;
            int p = Math.Max(0, Math.Min(docLen - 1, pos > 0 ? pos - 1 : 0));
            while (p > 0 && char.IsWhiteSpace(txt[p])) p--;
            int s = Editor.WordStartPosition(p, true);
            int e = Editor.WordEndPosition(p, true);
            if (e > s)
            {
                start = s; len = e - s; return true;
            }
            start = p; len = 1; return true;
        }
        private static IEnumerable<MetadataReference> GetBasicMetadataReferences()
        {
            var assemblies = new[] {
                typeof(object).Assembly,
                typeof(Console).Assembly,
                typeof(Enumerable).Assembly,
                typeof(List<>).Assembly,
                typeof(Task).Assembly,
                typeof(System.Runtime.GCSettings).Assembly
            };
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var list = new List<MetadataReference>();
            foreach (var asm in assemblies)
            {
                try
                {
                    var path = asm.Location;
                    if (!string.IsNullOrEmpty(path) && File.Exists(path) && seen.Add(path))
                        list.Add(MetadataReference.CreateFromFile(path));
                }
                catch { }
            }
            return list;
        }

        // ==== Folding Helpers (clean implementation) ====
        private class BraceBlock
        {
            public int OpenPos;
            public int ClosePos;
            public int OpenLine;
            public int CloseLine;
            public List<BraceBlock> Children = new();
            public BraceBlock? Parent; // NEU
            public bool Contains(int pos) => OpenPos <= pos && pos <= ClosePos;
        }
        private List<BraceBlock> BuildBraceForest()
        {
            var forest = new List<BraceBlock>();
            var stack = new Stack<BraceBlock>();
            for (int pos = 0; pos < Editor.TextLength; pos++)
            {
                int ch = Editor.GetCharAt(pos);
                if (ch == '{')
                {
                    var blk = new BraceBlock { OpenPos = pos, OpenLine = Editor.LineFromPosition(pos) };
                    if (stack.Count == 0) forest.Add(blk); else { var parent = stack.Peek(); parent.Children.Add(blk); blk.Parent = parent; }
                    stack.Push(blk);
                }
                else if (ch == '}' && stack.Count > 0)
                {
                    var blk = stack.Pop();
                    blk.ClosePos = pos;
                    blk.CloseLine = Editor.LineFromPosition(pos);
                }
            }
            forest = forest.Where(b => b.ClosePos > b.OpenPos).ToList();

            // Filter: entferne Auto-Property Accessor-Blöcke (z.B. { get; set; }) damit Methoden als direkte Kinder erkannt werden
            bool IsAccessorBlock(BraceBlock b)
            {
                if (b.OpenLine != b.CloseLine) return false; // nur einzeilige
                int innerLen = b.ClosePos - b.OpenPos - 1;
                if (innerLen <= 0) return false;
                string inner = Editor.GetTextRange(b.OpenPos + 1, innerLen);
                // Nur Schlüsselwörter get/set/init ; und evtl. Whitespace
                if (System.Text.RegularExpressions.Regex.IsMatch(inner, @"^\s*(?:get|set|init);(?:\s*(?:get|set|init);)*\s*$")) return true;
                return false;
            }
            void Prune(List<BraceBlock> list)
            {
                for (int i = list.Count - 1; i >= 0; i--)
                {
                    var b = list[i];
                    if (IsAccessorBlock(b)) { list.RemoveAt(i); continue; }
                    Prune(b.Children);
                }
            }
            Prune(forest);
            return forest;
        }
        private BraceBlock? FindDeepestContaining(BraceBlock blk, int caret)
        {
            if (!blk.Contains(caret)) return null;
            foreach (var child in blk.Children)
            {
                var hit = FindDeepestContaining(child, caret);
                if (hit != null) return hit;
            }
            return blk;
        }
        private ((int openLine, int closeLine, int openPos, int closePos)? parent, List<(int openLine, int closeLine, int openPos, int closePos)> directChildren) GetParentAndDirectChildren()
        {
            var forest = BuildBraceForest();
            int caret = Editor.CurrentPosition;
            BraceBlock? deepest = null;
            foreach (var root in forest)
            {
                var hit = FindDeepestContaining(root, caret);
                if (hit != null)
                {
                    if (deepest == null || (hit.OpenPos >= deepest.OpenPos && hit.ClosePos <= deepest.ClosePos)) deepest = hit;
                }
            }
            if (deepest == null) return (null, new());
            // Heuristik: Wenn wir in einem Block ohne Geschwister (oder mit Parent der viele Kinder hat) und der Block klein ist (z.B. if/loop innerhalb einer Methode), wähle einen höheren Block mit mehreren Kindern (z.B. Methoden innerhalb Klasse)
            BraceBlock chosen = deepest;
            bool IsSmall(BraceBlock b) => (b.CloseLine - b.OpenLine) < 3; // sehr kleiner Block
            if (chosen.Parent != null)
            {
                // Wenn der Parent >1 Kinder hat und chosen entweder klein ist oder Parent deutlich größer ist -> Parent benutzen
                if (chosen.Parent.Children.Count > 1 && (IsSmall(chosen) || (chosen.Parent.CloseLine - chosen.Parent.OpenLine) > (chosen.CloseLine - chosen.OpenLine) * 2))
                {
                    chosen = chosen.Parent;
                }
                else
                {
                    // Eine Ebene höher weiter gehen bis wir einen Block mit >1 Kindern finden (Klassenblock) falls aktueller nur genau ein Child enthält
                    var ascend = chosen;
                    while (ascend.Parent != null && ascend.Parent.Children.Count <= 1)
                        ascend = ascend.Parent;
                    if (ascend.Parent != null && ascend.Parent.Children.Count > 1)
                        chosen = ascend.Parent;
                }
            }
            var resultChildren = chosen.Children
                .Where(c => c.ClosePos > c.OpenPos)
                .Select(c => (c.OpenLine, c.CloseLine, c.OpenPos, c.ClosePos))
                .ToList();
            return ((chosen.OpenLine, chosen.CloseLine, chosen.OpenPos, chosen.ClosePos), resultChildren);
        }
        private void CollapseAllInnerBlocksExceptOuter()
        {
            var (parent, directChildren) = GetParentAndDirectChildren();
            if (parent == null || directChildren.Count == 0) return;
            foreach (var b in directChildren)
                if (!LineIsCollapsed(Editor, b.openLine)) Editor.Lines[b.openLine].ToggleFold();
        }
        private void ExpandAllBlocksAtCaret()
        {
            var (parent, directChildren) = GetParentAndDirectChildren();
            if (parent == null) return;
            foreach (var b in directChildren)
                if (LineIsCollapsed(Editor, b.openLine)) Editor.Lines[b.openLine].ToggleFold();
        }

        // Optionale gezielte Expand-Funktion nur für direkte Kinder (falls später benötigt)
        private static bool LineIsCollapsed(Scintilla sci, int headerLine)
        {
            if (headerLine + 1 >= sci.Lines.Count) return false;
            return !sci.Lines[headerLine + 1].Visible;
        }

        ContextMenuStrip EditorContextMenu = new ContextMenuStrip();
        private void InitEditorContextMenu()
        {
           

            var miGoto = new ToolStripMenuItem("Go To Definition (F12)");
            miGoto.Click += async (_, __) => await GoToDefinitionAsync();
            EditorContextMenu.Items.Add(miGoto);

            var miRename = new ToolStripMenuItem("Rename...");
            miRename.Click += async (_, __) => await RenameSymbolAsync();
            EditorContextMenu.Items.Add(miRename);

            EditorContextMenu.Items.Add(new ToolStripSeparator());

            var miCollapse = new ToolStripMenuItem("Collapse to Definition");
            miCollapse.Click += (_, __) => CollapseAllInnerBlocksExceptOuter();
            EditorContextMenu.Items.Add(miCollapse);

            var miExpand = new ToolStripMenuItem("Expand All");
            miExpand.Click += (_, __) => ExpandAllBlocksAtCaret();
            EditorContextMenu.Items.Add(miExpand);

            EditorContextMenu.Items.Add(new ToolStripSeparator());

            Editor.ContextMenuStrip = EditorContextMenu;
        }

        // ================= Signature Help =================
        private async Task<bool> TrySignatureHelpAsync(bool updateOnly = false)
        {
            if (_currentFile == null || !_selectedNode.Active || !_roslyn.IsProjectLoaded)
            {
                if (!updateOnly) Editor.CallTipCancel();
                return false;
            }
            int pos = Math.Max(0, Editor.CurrentPosition);
            await _roslyn.UpdateOpenDocumentAsync(_currentFile, Editor.Text);
            var doc = FindDocument(_currentFile);
            if (doc == null) { if (!updateOnly) Editor.CallTipCancel(); return false; }
            var tree = await doc.GetSyntaxTreeAsync().ConfigureAwait(false);
            if (tree == null) { if (!updateOnly) Editor.CallTipCancel(); return false; }
            var root = await tree.GetRootAsync().ConfigureAwait(false);
            var token = root.FindToken(Math.Max(0, pos - 1));
            var node = token.Parent;
            while (node != null)
            {
                if (node is InvocationExpressionSyntax inv && inv.ArgumentList != null)
                    return await ShowSignatureForInvocationAsync(inv, doc, pos, updateOnly);
                if (node is ObjectCreationExpressionSyntax obj && obj.ArgumentList != null)
                    return await ShowSignatureForCreationAsync(obj, doc, pos, updateOnly);
                node = node.Parent;
            }
            if (!updateOnly) Editor.CallTipCancel();
            return false;
        }
        private int GetArgumentIndex(ArgumentListSyntax list, int caretPos)
        {
            int idx = 0;
            foreach (var a in list.Arguments)
            {
                if (caretPos > a.FullSpan.Start) idx++; else break;
            }
            if (idx > 0 && idx == list.Arguments.Count && caretPos <= list.CloseParenToken.FullSpan.Start)
                idx--; // Cursor direkt hinter letztem Argument
            return Math.Max(0, idx);
        }
        private async Task<bool> ShowSignatureForInvocationAsync(InvocationExpressionSyntax inv, RoslynDocument doc, int caretPos, bool updateOnly)
        {
            var model = await doc.GetSemanticModelAsync().ConfigureAwait(false);
            if (model == null) { if (!updateOnly) Editor.CallTipCancel(); return false; }
            var info = model.GetSymbolInfo(inv);
            var methodGroup = info.Symbol != null ? new[] { info.Symbol } : (info.CandidateSymbols.IsDefaultOrEmpty ? Array.Empty<ISymbol>() : info.CandidateSymbols.ToArray());
            var methods = methodGroup.OfType<IMethodSymbol>().ToArray();
            if (methods.Length == 0)
            {
                var exprType = model.GetTypeInfo(inv.Expression).Type as INamedTypeSymbol;
                if (exprType != null)
                {
                    var name = inv.Expression switch
                    {
                        MemberAccessExpressionSyntax ma => ma.Name.Identifier.ValueText,
                        IdentifierNameSyntax id => id.Identifier.ValueText,
                        _ => null
                    };
                    if (!string.IsNullOrEmpty(name))
                        methods = exprType.GetMembers(name).OfType<IMethodSymbol>().ToArray();
                }
            }
            if (methods.Length == 0) { if (!updateOnly) Editor.CallTipCancel(); return false; }
            int argIndex = inv.ArgumentList != null ? GetArgumentIndex(inv.ArgumentList, caretPos) : 0;
            return ShowSignatureCallTip(methods[0].ContainingType, methods, argIndex, updateOnly);
        }
        private async Task<bool> ShowSignatureForCreationAsync(ObjectCreationExpressionSyntax obj, RoslynDocument doc, int caretPos, bool updateOnly)
        {
            var model = await doc.GetSemanticModelAsync().ConfigureAwait(false);
            if (model == null) { if (!updateOnly) Editor.CallTipCancel(); return false; }
            var type = model.GetTypeInfo(obj).Type as INamedTypeSymbol ?? model.GetSymbolInfo(obj.Type).Symbol as INamedTypeSymbol;
            if (type == null) { if (!updateOnly) Editor.CallTipCancel(); return false; }
            var ctors = type.InstanceConstructors.Where(c => !c.IsStatic).OrderBy(c => c.Parameters.Length).ToArray();
            if (ctors.Length == 0) { if (!updateOnly) Editor.CallTipCancel(); return false; }
            int argIndex = GetArgumentIndex(obj.ArgumentList!, caretPos);
            return ShowSignatureCallTip(type, ctors, argIndex, updateOnly);
        }
        private bool ShowSignatureCallTip(INamedTypeSymbol containerType, IEnumerable<IMethodSymbol> overloads, int argIndex, bool updateOnly)
        {
            var ordered = overloads.OrderBy(m => m.Parameters.Length).ToList();
            if (ordered.Count == 0) { if (!updateOnly) Editor.CallTipCancel(); return false; }
            var best = ordered.FirstOrDefault(m => m.Parameters.Length > argIndex) ?? ordered.First();
            var lines = new List<string>();
            var highlight = (start: -1, length: 0);
            int cumulative = 0;
            foreach (var m in ordered.Take(12))
            {
                var typeName = containerType.ToDisplayString(SymbolDisplayFormat.MinimallyQualifiedFormat);
                var namePart = m.MethodKind == MethodKind.Constructor ? typeName : typeName + "." + m.Name;
                var paramPieces = new List<string>();
                int highlightStartInLine = -1; int highlightLen = 0;
                for (int i = 0; i < m.Parameters.Length; i++)
                {
                    var p = m.Parameters[i];
                    string piece = p.ToDisplayString(SymbolDisplayFormat.MinimallyQualifiedFormat);
                    if (m.Equals(best) && i == argIndex)
                    {
                        highlightStartInLine = string.Join(", ", paramPieces).Length + (paramPieces.Count > 0 ? 2 : 0);
                        highlightLen = piece.Length;
                    }
                    paramPieces.Add(piece);
                }
                string line = namePart + "(" + string.Join(", ", paramPieces) + ")";

                lines.Add(line);
                if (highlightStartInLine >= 0 && highlightLen > 0)
                {
                    highlight.start = cumulative + namePart.Length + 1 + highlightStartInLine; // +1 for '('
                    highlight.length = highlightLen;
                }
                cumulative += line.Length + 1; // +1 newline
            }
            string text = string.Join("\n", lines);
            if (!Editor.CallTipActive)
                Editor.CallTipShow(Editor.CurrentPosition, text);
            else
            {
                Editor.CallTipCancel();
                Editor.CallTipShow(Editor.CurrentPosition, text);
            }
            if (highlight.start >= 0 && highlight.length > 0)
            {
                try { Editor.CallTipSetHlt(highlight.start, highlight.start + highlight.length); } catch { }
            }
            return true;
        }

        // ================= End Signature Help =================
        private void CommentSelection()
        {
            int selStart = Editor.SelectionStart;
            int selEnd = Editor.SelectionEnd;
            if (selEnd < selStart) (selStart, selEnd) = (selEnd, selStart);
            if (selStart == selEnd)
            {
                // keine Selektion -> aktuelle Zeile
                int line = Editor.LineFromPosition(selStart);
                selStart = Editor.Lines[line].Position;
                selEnd = Editor.Lines[line].EndPosition;
            }
            int startLine = Editor.LineFromPosition(selStart);
            int endLine = Editor.LineFromPosition(Math.Max(selEnd - 1, selStart));
            Editor.BeginUndoAction();
            try
            {
                int delta = 0;
                for (int line = startLine; line <= endLine; line++)
                {
                    int lineStart = Editor.Lines[line].Position;
                    int lineEnd = Editor.Lines[line].EndPosition; // inkl. \r\n vor letztem char
                    // Finde erste nicht-Whitespace Position
                    int p = lineStart;
                    while (p < lineEnd)
                    {
                        int ch = Editor.GetCharAt(p);
                        if (ch != ' ' && ch != '\t') break;
                        p++;
                    }
                    if (p >= lineEnd) continue; // leere / whitespace-only Zeile
                    // Prüfen ob bereits // vorhanden
                    bool already = p + 1 < lineEnd && Editor.GetCharAt(p) == '/' && Editor.GetCharAt(p + 1) == '/';
                    if (already) continue;
                    Editor.InsertText(p, "//");
                    if (line == startLine) selStart += 2; // Cursor verschiebt sich nach Einfügung vor Start
                    selEnd += 2;
                    delta += 2;
                }
                // Auswahl erneut setzen (optional beibehalten)
                Editor.SetSelection(selEnd, selStart); // ScintillaNET erwartet anchor/caret; Umkehren damit Selektion gleich bleibt
            }
            finally { Editor.EndUndoAction(); }
        }
        private void UncommentSelection()
        {
            int selStart = Editor.SelectionStart;
            int selEnd = Editor.SelectionEnd;
            if (selEnd < selStart) (selStart, selEnd) = (selEnd, selStart);
            if (selStart == selEnd)
            {
                int line = Editor.LineFromPosition(selStart);
                selStart = Editor.Lines[line].Position;
                selEnd = Editor.Lines[line].EndPosition;
            }
            int startLine = Editor.LineFromPosition(selStart);
            int endLine = Editor.LineFromPosition(Math.Max(selEnd - 1, selStart));
            Editor.BeginUndoAction();
            try
            {
                for (int line = startLine; line <= endLine; line++)
                {
                    int lineStart = Editor.Lines[line].Position;
                    int lineEnd = Editor.Lines[line].EndPosition;
                    int p = lineStart;
                    while (p < lineEnd)
                    {
                        int ch = Editor.GetCharAt(p);
                        if (ch != ' ' && ch != '\t') break;
                        p++;
                    }
                    if (p + 1 >= lineEnd) continue;
                    if (Editor.GetCharAt(p) == '/' && Editor.GetCharAt(p + 1) == '/')
                    {
                        Editor.DeleteRange(p, 2);
                        if (p < selStart) selStart = Math.Max(lineStart, selStart - 2);
                        selEnd = Math.Max(selStart, selEnd - 2);
                    }
                }
                Editor.SetSelection(selEnd, selStart);
            }
            finally { Editor.EndUndoAction(); }
        }

        // Verschiebe Suchmethoden weiter nach oben damit sie vor erster Verwendung vorhanden sind
        private void ExecuteSearch(bool next)
        {
            if (_searchBar == null) return;
            var pattern = _searchBar.SearchText;
            if (string.IsNullOrWhiteSpace(pattern)) return;

            // Reset state when pattern or scope changed
            if (_searchBar.Scope == SearchScope.Project)
            {
                if (!string.Equals(pattern, _projectSearchPatternCache, StringComparison.Ordinal))
                {
                    _projectSearchPatternCache = pattern;
                    _projectSearchFileCache = null;
                    _projectSearchCurrentFileIndex = -1;
                    _lastSearchPos = -1;
                }
                SearchProjectSequential(pattern, next);
            }
            else // Document
            {
                _projectSearchPatternCache = null;
                _projectSearchFileCache = null;
                SearchInDocument(pattern, next);
            }
        }
        private void SearchInDocument(string pattern, bool next)
        {
            var text = Editor.Text;
            int startPos = Editor.SelectionEnd;
            if (!next) _lastSearchPos = -1;
            int searchFrom = _lastSearchPos >= 0 ? _lastSearchPos + 1 : startPos;
            if (searchFrom >= text.Length) searchFrom = 0;
            int idx = text.IndexOf(pattern, searchFrom, StringComparison.OrdinalIgnoreCase);
            if (idx < 0 && searchFrom > 0) idx = text.IndexOf(pattern, 0, StringComparison.OrdinalIgnoreCase);
            if (idx >= 0)
            {
                _lastSearchPos = idx;
                Editor.SetSelection(idx + pattern.Length, idx);
                Editor.ScrollCaret();
            }
        }
        private void SearchProjectSequential(string pattern, bool next)
        {
            if (string.IsNullOrEmpty(_projectRoot)) { SearchInDocument(pattern, next); return; }
            if (_projectSearchFileCache == null)
            {
                _projectSearchFileCache = Directory.GetFiles(_projectRoot, "*.cs", SearchOption.AllDirectories);
                Array.Sort(_projectSearchFileCache, StringComparer.OrdinalIgnoreCase);
                _projectSearchCurrentFileIndex = _projectSearchFileCache.ToList().FindIndex(f => string.Equals(f, _currentFile, StringComparison.OrdinalIgnoreCase));
                if (_projectSearchCurrentFileIndex < 0) _projectSearchCurrentFileIndex = 0;
                _lastSearchPos = -1;
            }
            if (_projectSearchCurrentFileIndex >= _projectSearchFileCache.Length) _projectSearchCurrentFileIndex = 0;
            var currentFile = _projectSearchFileCache[_projectSearchCurrentFileIndex];
            if (!string.Equals(currentFile, _currentFile, StringComparison.OrdinalIgnoreCase))
            {
                OpenFile(currentFile);
                SelectProjectTreeNodeByPath(currentFile);
                _lastSearchPos = -1;
            }
            var text = Editor.Text;
            int startFrom = _lastSearchPos + 1;
            if (startFrom < 0) startFrom = 0;
            int idx = startFrom < text.Length ? text.IndexOf(pattern, startFrom, StringComparison.OrdinalIgnoreCase) : -1;
            if (idx < 0 && startFrom > 0)
                idx = text.IndexOf(pattern, 0, StringComparison.OrdinalIgnoreCase);
            if (idx >= 0)
            {
                _lastSearchPos = idx;
                Editor.SetSelection(idx + pattern.Length, idx);
                Editor.ScrollCaret();
                return;
            }
            for (int advance = 1; advance <= _projectSearchFileCache.Length; advance++)
            {
                int nextFileIndex = (_projectSearchCurrentFileIndex + advance) % _projectSearchFileCache.Length;
                var file = _projectSearchFileCache[nextFileIndex];
                try
                {
                    var content = File.ReadAllText(file);
                    int hit = content.IndexOf(pattern, StringComparison.OrdinalIgnoreCase);
                    if (hit >= 0)
                    {
                        _projectSearchCurrentFileIndex = nextFileIndex;
                        OpenFile(file);
                        SelectProjectTreeNodeByPath(file);
                        _lastSearchPos = hit;
                        Editor.SetSelection(hit + pattern.Length, hit);
                        Editor.ScrollCaret();
                        return;
                    }
                }
                catch { }
            }
        }
        private void ShowSearchBar()
        {
            if (_currentTheme == EditorTheme.Dark) _searchBar.DarkTheme(); else _searchBar.LightTheme();

            if (_replaceBar.Visible) _replaceBar.Visible = false;
            PositionSearchBar();
            if (!_searchBar.Visible) _searchBar.Visible = true;
            _searchBar.ClearAndFocus();
        }
        private void ShowReplaceBar()
        {
            if (_currentTheme == EditorTheme.Dark) _replaceBar.DarkTheme(); else _replaceBar.LightTheme();

            // Nur ReplaceBar anzeigen (SearchBar ausblenden)
            if (_searchBar.Visible) _searchBar.Visible = false;
            if (!_replaceBar.Visible) _replaceBar.Visible = true;
            PositionSearchBar();
            // Falls vorher im Editor etwas selektiert war, initialisiere Find-Text
            if (Editor.SelectionStart != Editor.SelectionEnd)
            {
                int len = Editor.SelectionEnd - Editor.SelectionStart;
                string sel = Editor.GetTextRange(Editor.SelectionStart, len);
                if (!string.IsNullOrWhiteSpace(sel) && !sel.Contains('\n')) _replaceBar.SetFindText(sel);
            }
            _replaceBar.FocusFind();
        }

        // Re-implementierte Replace-Methoden (endgültige Version) und TreeNode Auswahl
        private void ReplaceFindNext()
        {
            if (!_replaceBar.Visible) return;
            string pattern = _replaceBar.FindText;
            if (string.IsNullOrEmpty(pattern)) return;
            if (_replaceBar.Scope == ReplaceScope.Project)
            {
                ReplaceProjectFindNextInternal(pattern);
                return;
            }
            int start = Editor.SelectionEnd;
            string text = Editor.Text;
            int idx = text.IndexOf(pattern, start, StringComparison.OrdinalIgnoreCase);
            if (idx < 0 && start > 0)
                idx = text.IndexOf(pattern, 0, StringComparison.OrdinalIgnoreCase);
            if (idx >= 0)
            {
                Editor.SetSelection(idx + pattern.Length, idx);
                Editor.ScrollCaret();
            }
        }
        private void ReplaceSingle()
        {
            if (!_replaceBar.Visible) return;
            string find = _replaceBar.FindText;
            string repl = _replaceBar.ReplaceText ?? string.Empty;
            if (string.IsNullOrEmpty(find)) return;

            int selLen = Editor.SelectionEnd - Editor.SelectionStart;
            bool selectionMatches = false;
            if (selLen > 0)
            {
                string sel = Editor.GetTextRange(Editor.SelectionStart, selLen); // length statt Endposition
                selectionMatches = string.Equals(sel, find, StringComparison.OrdinalIgnoreCase);
            }
            if (!selectionMatches)
            {
                ReplaceFindNext();
                selLen = Editor.SelectionEnd - Editor.SelectionStart;
                if (selLen > 0)
                {
                    string sel = Editor.GetTextRange(Editor.SelectionStart, selLen); // length statt Endposition
                    selectionMatches = string.Equals(sel, find, StringComparison.OrdinalIgnoreCase);
                }
            }
            if (selectionMatches)
            {
                Editor.ReplaceSelection(repl);
                ReplaceFindNext();
            }
        }
        private void ReplaceAll()
        {
            if (!_replaceBar.Visible) return;
            string find = _replaceBar.FindText;
            string repl = _replaceBar.ReplaceText ?? string.Empty;
            if (string.IsNullOrEmpty(find)) return;
            switch (_replaceBar.Scope)
            {
                case ReplaceScope.Selection:
                    if (Editor.SelectionStart == Editor.SelectionEnd) return;
                    int start = Editor.SelectionStart;
                    int len = Editor.SelectionEnd - start;
                    string sel = Editor.GetTextRange(start, len);
                    string replacedSel = ReplaceAllOccurrences(sel, find, repl);
                    if (!ReferenceEquals(sel, replacedSel))
                    {
                        Editor.TargetStart = start;
                        Editor.TargetEnd = start + len;
                        Editor.ReplaceSelection(replacedSel);
                        Editor.SetSelection(start + replacedSel.Length, start);
                    }
                    break;
                case ReplaceScope.Document:
                    string doc = Editor.Text;
                    string replacedDoc = ReplaceAllOccurrences(doc, find, repl);
                    if (!ReferenceEquals(doc, replacedDoc))
                    {
                        int caret = Editor.CurrentPosition;
                        Editor.Text = replacedDoc;
                        Editor.GotoPosition(Math.Min(caret, Editor.TextLength));
                    }
                    break;
                case ReplaceScope.Project:
                    if (string.IsNullOrEmpty(_projectRoot)) { ReplaceAllOccurrences(Editor.Text, find, repl); return; }
                    var files = Directory.GetFiles(_projectRoot, "*.cs", SearchOption.AllDirectories);
                    foreach (var file in files)
                    {
                        try
                        {
                            string content = File.ReadAllText(file);
                            string replaced = ReplaceAllOccurrences(content, find, repl);
                            if (!ReferenceEquals(content, replaced))
                            {
                                File.WriteAllText(file, replaced);
                                if (string.Equals(file, _currentFile, StringComparison.OrdinalIgnoreCase))
                                {
                                    int caret = Editor.CurrentPosition;
                                    Editor.Text = replaced;
                                    Editor.GotoPosition(Math.Min(caret, Editor.TextLength));
                                    SelectProjectTreeNodeByPath(file);
                                }
                            }
                        }
                        catch { }
                    }
                    // Reset Replace-Project Cache damit weitere ReplaceFindNext korrekt startet
                    _replaceProjectPatternCache = null;
                    _replaceProjectFileCache = null;
                    _replaceProjectCurrentFileIndex = -1;
                    _replaceProjectLastPos = -1;
                    break;
            }
        }
        private void SelectProjectTreeNodeByPath(string filePath)
        {
            if (ProjectTree == null) return;
            TreeNode? found = null;
            foreach (TreeNode root in ProjectTree.Nodes)
            {
                found = FindNodeRecursive(root, filePath);
                if (found != null) break;
            }
            if (found != null)
            {
                ProjectTree.SelectedNode = found;
                found.EnsureVisible();
            }
        }

        // --- Scintilla Events ---
        private void Scintilla_CharAdded(object sender, CharAddedEventArgs e)
        {

        }
        private void PositionSearchBar()
        {
            if (_searchBar == null || Editor == null) return;
            var editorLocation = Editor.PointToScreen(Point.Empty);
            var formLocation = this.PointToScreen(Point.Empty);
            int editorRight = editorLocation.X - formLocation.X + Editor.Width;
            int editorTop = editorLocation.Y - formLocation.Y;
            _searchBar.Location = new Point(editorRight - _searchBar.Width - 8, editorTop + 4);
            if (_replaceBar.Visible)
                _replaceBar.Location = new Point(editorRight - _replaceBar.Width - 8, editorTop + 4);
            _editorTopRightCache = new Point(editorRight, editorTop);
        }

        private static string ReplaceAllOccurrences(string source, string find, string repl)
        {
            if (string.IsNullOrEmpty(find)) return source;
            int idx = source.IndexOf(find, StringComparison.OrdinalIgnoreCase);
            if (idx < 0) return source;
            var sb = new System.Text.StringBuilder();
            int last = 0; int findLen = find.Length;
            while (idx >= 0)
            {
                sb.Append(source, last, idx - last);
                sb.Append(repl);
                last = idx + findLen;
                idx = source.IndexOf(find, last, StringComparison.OrdinalIgnoreCase);
            }
            sb.Append(source, last, source.Length - last);
            return sb.ToString();
        }
        private TreeNode? FindNodeRecursive(TreeNode node, string filePath)
        {
            if (node.Tag is string tagPath && string.Equals(tagPath, filePath, StringComparison.OrdinalIgnoreCase))
                return node;
            foreach (TreeNode child in node.Nodes)
            {
                var hit = FindNodeRecursive(child, filePath);
                if (hit != null) return hit;
            }
            return null;
        }

        // --- interne Implementierungen ---
        private void ReplaceProjectFindNextInternal(string pattern)
        {
            if (string.IsNullOrEmpty(_projectRoot)) { return; }
            if (!string.Equals(pattern, _replaceProjectPatternCache, StringComparison.Ordinal))
            {
                _replaceProjectPatternCache = pattern;
                _replaceProjectFileCache = null;
                _replaceProjectCurrentFileIndex = -1;
                _replaceProjectLastPos = -1;
            }
            if (_replaceProjectFileCache == null)
            {
                _replaceProjectFileCache = Directory.GetFiles(_projectRoot, "*.cs", SearchOption.AllDirectories);
                Array.Sort(_replaceProjectFileCache, StringComparer.OrdinalIgnoreCase);
                _replaceProjectCurrentFileIndex = _replaceProjectFileCache.ToList().FindIndex(f => string.Equals(f, _currentFile, StringComparison.OrdinalIgnoreCase));
                if (_replaceProjectCurrentFileIndex < 0) _replaceProjectCurrentFileIndex = 0;
                _replaceProjectLastPos = -1;
            }
            if (_replaceProjectFileCache.Length == 0) return;
            if (_replaceProjectCurrentFileIndex >= _replaceProjectFileCache.Length) _replaceProjectCurrentFileIndex = 0;
            var curFile = _replaceProjectFileCache[_replaceProjectCurrentFileIndex];
            if (!string.Equals(curFile, _currentFile, StringComparison.OrdinalIgnoreCase))
            {
                OpenFile(curFile);
                SelectProjectTreeNodeByPath(curFile);
                _replaceProjectLastPos = -1;
            }
            var text = Editor.Text;
            int from = _replaceProjectLastPos + 1;
            if (from < 0) from = 0;
            int idx = from < text.Length ? text.IndexOf(pattern, from, StringComparison.OrdinalIgnoreCase) : -1;
            if (idx >= 0)
            {
                _replaceProjectLastPos = idx;
                Editor.SetSelection(idx + pattern.Length, idx);
                Editor.ScrollCaret();
                return;
            }
            for (int advance = 1; advance <= _replaceProjectFileCache.Length; advance++)
            {
                int nextIndex = (_replaceProjectCurrentFileIndex + advance) % _replaceProjectFileCache.Length;
                var file = _replaceProjectFileCache[nextIndex];
                try
                {
                    var content = File.ReadAllText(file);
                    int hit = content.IndexOf(pattern, StringComparison.OrdinalIgnoreCase);
                    if (hit >= 0)
                    {
                        _replaceProjectCurrentFileIndex = nextIndex;
                        OpenFile(file);
                        SelectProjectTreeNodeByPath(file);
                        _replaceProjectLastPos = hit;
                        Editor.SetSelection(hit + pattern.Length, hit);
                        Editor.ScrollCaret();
                        return;
                    }
                }
                catch { }
            }
        }

        public static class SimpleIndentFormatter
        {
            public static string Reindent(string source, int indentSize = 4)
            {
                if (string.IsNullOrEmpty(source)) return source;
                var sb = new StringBuilder(source.Length + 1024);
                var lines = source.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
                int level = 0;

                for (int i = 0; i < lines.Length; i++)
                {
                    var raw = lines[i];
                    var trimmed = raw.Trim();
                    if (trimmed.Length == 0) { sb.AppendLine(); continue; }

                    // Wenn die Zeile mit '}' beginnt, vorher Level reduzieren
                    if (trimmed.Length > 0 && trimmed[0] == '}')
                        level = Math.Max(0, level - 1);

                    // Neue Einrückung berechnen
                    int spaces = level * indentSize;
                    sb.Append(' ', spaces);
                    sb.AppendLine(trimmed);

                    // Level-Anpassung je nach Brace-Bilanz am Ende der Zeile
                    // (einfacher Heuristik-Ansatz; Strings/Comments werden nicht geparst)
                    int open = CountChar(trimmed, '{');
                    int close = CountChar(trimmed, '}');
                    level += open - close;
                    if (level < 0) level = 0; // robust gegen unbalancierte Fälle
                }
                return sb.ToString();
            }
            private static int CountChar(string s, char c)
            {
                int n = 0; foreach (var ch in s) if (ch == c) n++; return n;
            }
        }
        private async Task FormatDocumentAsync()
        {
            string input = Editor.Text;

      

            string? roslyn = await RoslynServices.FormatCSharpAsync(
            input,
            useTabs: false,
            indentSize: 4
            );


            string output = roslyn ?? SimpleIndentFormatter.Reindent(input, 4);


            if (!string.Equals(input, output, StringComparison.Ordinal))
            {
                int pos = Editor.CurrentPosition; // Cursor merken
                Editor.Text = output;


                if (_selectedNode.Type == EditorNode.NodeType.SubCode)
                {
                 
                        var (startLine, endLine) = _selectedNode.GetUsingBlockLineRange();
                        Editor.HideLines(startLine, endLine);
                  

                }

                Editor.SetEmptySelection(Math.Min(pos, Editor.TextLength));
            }
        }


        //================= Code Edit //=================

        void IncludeCode(EditorNode node)
        {
            node.PageNode.AddUndo(Editor.Text, Editor.CurrentPosition, Editor.FirstVisibleLine);
            List<string> lines = File.ReadAllLines(node.PageNode.FilePath).ToList();
            List<string> updatedLines = new List<string>();

            string newInclude = "//+include " + node.Text;
            bool includeExists = lines.Contains(newInclude);
            int lastIncludeIndex = -1;

            // Finde die letzte Zeile mit einem Include
            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].Trim().Contains("//+include") && lines[i].EndsWith(node.Text)) return;
                
                if (lines[i].Trim().StartsWith("//+include"))
                {
                    lastIncludeIndex = i;
                }
            }
            Debug.WriteLine("Index " + lastIncludeIndex);
            if(lastIncludeIndex == -1)
            {
                for (int i = 0; i < lines.Count; i++)
                {
                    if (lines[i].Trim().StartsWith("public class"))
                    {
                        lastIncludeIndex = i + 2;
                    }
                }
            }

            // Wenn Include bereits existiert, nichts tun
            if (includeExists)
            {
                Debug.WriteLine("Include already exists");
                return;
            }

            // Füge neue Include-Zeile direkt nach dem letzten Include ein
            for (int i = 0; i < lines.Count; i++)
            {
                updatedLines.Add(lines[i]);

                if (i == lastIncludeIndex)
                {
                    updatedLines.Add("\t" + newInclude);
                }
            }
            node.Active = true;
            OpendNode(node);


            File.WriteAllLines(node.PageNode.FilePath, updatedLines);
        }

        void ExcludeCode(EditorNode node)
        {
            node.PageNode.AddUndo(Editor.Text, Editor.CurrentPosition, Editor.FirstVisibleLine);
            List<string> lines = File.ReadAllLines(node.PageNode.FilePath).ToList();
            string remove = $"//+include {node.Text}";
            lines.RemoveAll(line => line.Trim().Contains("//+include") && line.EndsWith(node.Text));
            node.Active = false;
            OpendNode(node);
            File.WriteAllLines(node.PageNode.FilePath, lines);
        }

        //================= Output / Build Output =================

        void InitOutput()
        {
            dataGridOutput = new DataGridView();
            tblEditorOutputs = new DataTable();
            tblEditorOutputs.Columns.Add("N", typeof(int));
            tblEditorOutputs.Columns.Add("Position", typeof(string));
            tblEditorOutputs.Columns.Add("Length", typeof(int));
            tblEditorOutputs.Columns.Add("Type", typeof(string));
            tblEditorOutputs.Columns.Add("Description", typeof(string));

            dataGridOutput.DataSource = tblEditorOutputs;

            dataGridOutput.DataBindingComplete += (s, e) =>
            {
                dataGridOutput.Columns["N"].Width = 30;
                dataGridOutput.Columns["Position"].Width = 100;
                dataGridOutput.Columns["Length"].Width = 50;
                dataGridOutput.Columns["Type"].Width = 80;
                dataGridOutput.Columns["Description"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            };


            dataGridOutput.AllowUserToResizeColumns = false;
            dataGridOutput.AllowUserToAddRows = false;
            dataGridOutput.RowHeadersVisible = false;
            dataGridOutput.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridOutput.MultiSelect = false;
            dataGridOutput.ReadOnly = true;
            dataGridOutput.BackgroundColor = Color.White;
            dataGridOutput.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridOutput.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridOutput.ColumnHeadersVisible = false;
            dataGridOutput.RowHeadersVisible = false;
            dataGridOutput.Dock = DockStyle.Fill;
            dataGridOutput.AllowUserToAddRows = false;
            dataGridOutput.AllowUserToDeleteRows = false;
            dataGridOutput.AllowUserToOrderColumns = true;
            dataGridOutput.AllowUserToResizeColumns = false;
            dataGridOutput.BackgroundColor = System.Drawing.Color.LightGray;
            dataGridOutput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridOutput.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridOutput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridOutput.ColumnHeadersVisible = false;
            dataGridOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            dataGridOutput.Location = new System.Drawing.Point(46, 25);
            dataGridOutput.Margin = new System.Windows.Forms.Padding(0);
            dataGridOutput.Name = "dataGridOutput";
            dataGridOutput.Size = new System.Drawing.Size(832, 115);
            dataGridOutput.TabIndex = 0;
            dataGridOutput.CellFormatting += (s, e) =>
            {
                if (dataGridOutput.Columns[e.ColumnIndex].Name == "Type")
                {
                    string severity = e.Value?.ToString();
                    switch (severity)
                    {
                        case "Error":
                            dataGridOutput.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Tomato;
                            break;
                        case "Warning":
                            dataGridOutput.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightYellow;
                            break;
                        case "Info":
                            dataGridOutput.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightBlue;
                            break;
                    }
                }
            };
            dataGridOutput.CellClick += (s, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    string pos = dataGridOutput.Rows[e.RowIndex].Cells["Position"].Value.ToString();
                    int length = Convert.ToInt32(dataGridOutput.Rows[e.RowIndex].Cells["Length"].Value);
                    EditorOutputJumpToPosition(pos, length);
                }
            };
     
            tblBuildOutputs = new DataTable();
            dataGridBuild = new DataGridView();
            tblBuildOutputs.Columns.Add("Page", typeof(string));
            tblBuildOutputs.Columns.Add("Class", typeof(string));
            tblBuildOutputs.Columns.Add("Position", typeof(string));
            tblBuildOutputs.Columns.Add("Length", typeof(int));
            tblBuildOutputs.Columns.Add("Type", typeof(string));
            tblBuildOutputs.Columns.Add("Description", typeof(string));
            tblBuildOutputs.Columns.Add("Node", typeof(EditorNode));

            dataGridBuild.DataBindingComplete += (s, e) =>
            {
                dataGridBuild.Columns["Page"].Width = 100;
                dataGridBuild.Columns["Class"].Width = 100;
                dataGridBuild.Columns["Position"].Width = 0;
                dataGridBuild.Columns["Length"].Width = 0;
                dataGridBuild.Columns["Type"].Width = 80;
                dataGridBuild.Columns["Node"].Width = 0;

                dataGridBuild.Columns["Description"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            };
            dataGridBuild.AllowUserToResizeColumns = false;

            dataGridBuild.DataSource = tblBuildOutputs;
            dataGridBuild.AllowUserToResizeColumns = false;
            dataGridBuild.AllowUserToAddRows = false;
            dataGridBuild.RowHeadersVisible = false;
            dataGridBuild.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridBuild.MultiSelect = false;
            dataGridBuild.ReadOnly = true;
            dataGridBuild.BackgroundColor = Color.White;
            dataGridBuild.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridBuild.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridBuild.ColumnHeadersVisible = false;
            dataGridBuild.RowHeadersVisible = false;
            dataGridBuild.Dock = DockStyle.Fill;
            dataGridBuild.AllowUserToAddRows = false;
            dataGridBuild.AllowUserToDeleteRows = false;
            dataGridBuild.AllowUserToOrderColumns = true;
            dataGridBuild.AllowUserToResizeColumns = false;
            dataGridBuild.BackgroundColor = System.Drawing.Color.LightGray;
            dataGridBuild.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridBuild.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridBuild.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridBuild.ColumnHeadersVisible = false;
            dataGridBuild.Dock = System.Windows.Forms.DockStyle.Fill;
            dataGridBuild.Location = new System.Drawing.Point(46, 25);
            dataGridBuild.Margin = new System.Windows.Forms.Padding(0);
            dataGridBuild.Name = "dataGridOutput";
            dataGridBuild.Size = new System.Drawing.Size(832, 115);
            dataGridBuild.TabIndex = 0;
            dataGridBuild.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridBuild.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridBuild.CellFormatting += (s, e) =>
            {
                if (dataGridBuild.Columns[e.ColumnIndex].Name == "Type")
                {
                    string severity = e.Value?.ToString();
                    switch (severity)
                    {
                        case "Error":
                            dataGridBuild.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Tomato;
                            break;
                        case "Warning":
                            dataGridBuild.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightYellow;
                            break;
                        case "Info":
                            dataGridBuild.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightBlue;
                            break;
                    }
                }
            };
            dataGridBuild.CellClick += (s, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    string pageName = dataGridBuild.Rows[e.RowIndex].Cells["Page"].Value.ToString();
                    string className = dataGridBuild.Rows[e.RowIndex].Cells["Class"].Value.ToString();
                    string pos = dataGridBuild.Rows[e.RowIndex].Cells["Position"].Value.ToString();
                    int length = Convert.ToInt32(dataGridBuild.Rows[e.RowIndex].Cells["Length"].Value);
                    EditorNode node = (EditorNode)dataGridBuild.Rows[e.RowIndex].Cells["Node"].Value;
                    TableBuildJumpToPosition(pageName, className, pos, length, node);
                }
            };

        }
        public void TableOutputClear()
        {
            if (tblEditorOutputs == null) return;
            tblEditorOutputs.Clear();
        }
        public void TableBuildClear()
        {
            if (tblBuildOutputs == null) return;
            tblBuildOutputs.Clear();
        }
        public void TableOutputAdd(int n, string position, int length, string type, string description)
        {
            if (tblEditorOutputs == null) return;
            tblEditorOutputs.Rows.Add(n, position, length, type, description);
        }

        internal void TableBuildAdd(
            string page, 
            string className, 
            string position, 
            int length, 
            string type, 
            string description, 
            EditorNode node)
        {
            if (tblBuildOutputs == null) return;
            tblBuildOutputs.Rows.Add(page, className, position, length, type, description, node);
        }

        public virtual void EditorOutputJumpToPosition(string pos, int length)
        {
            int p = Convert.ToInt32(pos);

            int lineNumber = Editor.LineFromPosition(p);
            int col = Editor.GetColumn(p);
            Debug.WriteLine("Column number " + col);
            int lineStartPos = Editor.Lines[lineNumber].Position;
            Editor.GotoPosition(lineStartPos);

            Editor.SelectionStart = p;
            Editor.SelectionEnd = p + length;
        }
        internal virtual void TableBuildJumpToPosition(string pageName, string className, string pos, int length, EditorNode node)
        {
            _selectedNode.ForeColor = ProjectTree.ForeColor;
            _selectedNode = node;
            _currentFile = node.FilePath;
            Editor.Text = File.ReadAllText(node.FilePath);
            _selectedNode.ForeColor = _currentTheme == EditorTheme.Dark ? Color.Plum : Color.Purple;



            int p = int.Parse(pos);
            int lineNumber = Editor.LineFromPosition(p);
            int col = Editor.GetColumn(p);
            Debug.WriteLine("Column number " + col);
            int lineStartPos = Editor.Lines[lineNumber].Position;
            Editor.GotoPosition(lineStartPos);

            Editor.SelectionStart = p;
            Editor.SelectionEnd = p + length;


            //if (pageName.Length<1 || className.Length < 1 || pos.Length < 1)
            //{
            //    Debug.WriteLine("PageName or ClassName or Position is null");
            //    return;
            //}
            //TreeNode page = null;
            //foreach (EditorNode node in ProjectTree.Nodes[0].Nodes)
            //{
            //    if (node.Text == pageName)
            //        page = node;
            //}
            //if (page == null)
            //{
            //    Debug.WriteLine("Page not found: " + pageName);
            //    return;
            //}
            //Debug.WriteLine("Page is" + page.Text);
            //foreach (EditorNode subnode in page.Nodes)
            //{
            //   if(subnode.Text == className)
            //    {
            //        Debug.WriteLine("node name: " + subnode.Text);
            //        PageData pd = (PageData)subnode.Tag;
            //        Debug.WriteLine("c# file" + subnode.FilePath);
            //        ProjectTree.SelectedNode = subnode;
            //        OpenFile(subnode.FilePath);

            //        int p = int.Parse(pos);
            //        int lineNumber = Editor.LineFromPosition(p);
            //        int col = Editor.GetColumn(p);
            //        Debug.WriteLine("Column number " + col);
            //        int lineStartPos = Editor.Lines[lineNumber].Position;
            //        Editor.GotoPosition(lineStartPos);

            //        Editor.SelectionStart = p;
            //        Editor.SelectionEnd = p + length;
            //    }
            //}

        }
        public List<string> ExtractIncludes(string source)
        {
          
            Debug.WriteLine("===== ExtractIncludes ======");
            Debug.WriteLine(source);
            if (string.IsNullOrWhiteSpace(source)) return new List<string>();
            var result = new List<string>();
            var regex = new Regex(@"//\+include\s+(\w+)", RegexOptions.Compiled);

            foreach (Match match in regex.Matches(source))
            {
                result.Add(match.Groups[1].Value);
            }
            Debug.WriteLine("=====  ======");
            return result;
        }
        public void SaveCode()
        {

            foreach(EditorNode node in RootNode.Nodes)
            {
                node.Save();
                foreach (EditorNode subnode in node.Nodes)
                {
                    Debug.WriteLine("Save " + subnode.Text);
                    subnode.Save();
                }
            }
            qbook.Core.ThisBook.Serialize();
            qbook.Core.ThisBook.Modified = false;
        }
        internal void OpendNode(EditorNode node)
        {
            if (_selectedNode != null) 
            {
                _selectedNode.LastCursorPos = Editor.CurrentPosition;
                _selectedNode.LastFirstLine = Editor.FirstVisibleLine;
                _selectedNode.ForeColor = ProjectTree.ForeColor;
            }



            _selectedNode = node;
            _currentFile = node.FilePath;

            if(_selectedNode.Tab == null)
            {
                _selectedNode.Tab = new EditorTab(_selectedNode,this);
            }

            if (!PanelTabs.Controls.Contains(_selectedNode.Tab))
            {
                PanelTabs.Controls.Add(_selectedNode.Tab);
            }

            Editor.Text = File.ReadAllText(node.FilePath);

            if (node.LastCursorPos >= 0)
            {
                Editor.FirstVisibleLine = node.LastFirstLine;
                Editor.GotoPosition(node.LastCursorPos);
            }


            _selectedNode.ForeColor = _currentTheme == EditorTheme.Dark ? Color.Plum : Color.Purple;
            UpdateMethodes();
            if (!node.Active) return;

            Text = $"AmiumCode - {Path.GetFileName(_currentFile)}";
            _ = _roslyn.UpdateOpenDocumentAsync(_currentFile, Editor.Text);

            var csproj = FindCsprojNear(_currentFile);
            if (csproj != null)
                _ = _roslyn.LoadProjectAsync(csproj);
            InitializeFolding();
            _ = RefreshSemanticOverlaysAsync();

            ProjectTree.SelectedNode = node;
            node.EnsureVisible();
            node.Expand();
        }
        public void SelectPageNodeByName(string pageName)
        {
            ProjectTree.SelectedNode = null;
            foreach (EditorNode node in ProjectTree.Nodes[0].Nodes)
            {
                if (node.Text.EndsWith(pageName))
                {
                    ProjectTree.SelectedNode = node;
                    node.EnsureVisible();
                    node.Expand();
                    OpendNode(node);
                    UpdateTabs();
                    break;

     
                }
            }
        }
        
        void RenameSubCode(oPage page, string oldKey, string newKey)
        {
            if (page.CsCodeExtra.ContainsKey(newKey))
            {
                MessageBox.Show("A custom code with this name already exists. Please choose a different name.");
                return;
            }

            var list = page.CsCodeExtra.ToList();
            list.Reverse();
            SerializableDictionary<string, string> dict = new SerializableDictionary<string, string>();
            foreach (var code in list)
            {
                if (code.Key != oldKey)
                    dict[code.Key] = code.Value;
                else
                    dict[newKey] = code.Value;
            }

            page.CsCodeExtra = dict;
        }
        private async Task DoRun()
        {
            if (qbook.Core.csScript == null)
            {
                try
                {
                    await qbook.Core.CsScriptRebuildAll(); //BuildCsScriptAll();
                }
                catch (Exception ex)
                {
                    SetStatusText("#ERR: rebuilding... (see Output)", Color.Red);
                    return;
                }
            }

            try
            {
                SetStatusText("running...",Color.White);
           

                var buildRunTrialPath = Path.Combine(qbook.Core.ThisBook.Directory, qbook.Core.ThisBook.Filename) + "~buildrun~";
                if (File.Exists(buildRunTrialPath))
                    File.Delete(buildRunTrialPath);

                qbook.Core.RunCsScript_Run();
          
            }
            catch (Exception ex)
            {
                SetStatusText("#ERR running... (see Output)", Color.Red);
            }
        }

        void SetStatusText(string text, Color? color = null, Color? backColor = null)
        {
            if (color == null)
                color = Color.Black;
            if (backColor == null)
                backColor = SystemColors.Control;

            labelStatus.BeginInvoke((Action)(() =>
            {
                labelStatus.Text = text; 
            }));
        }


        //========================= UI Events =========================

        private void btnFind_Click(object sender, EventArgs e)
        {
            ShowSearchBar();
        }
        private void btnFindReplace_Click(object sender, EventArgs e)
        {
            ShowReplaceBar();
        }
        private void btnSnippets_Click(object sender, EventArgs e)
        {

        }
        private void btnParagraph_Click(object sender, EventArgs e)
        {
            if (Editor.ViewEol)
            {
                Editor.ViewEol = false;         // Zeigt die EOL-Zeichen visuell an
                Editor.ViewWhitespace = WhitespaceMode.Invisible;

            }
            else
            {
                Editor.EolMode = Eol.CrLf;
                Editor.ViewEol = true;         // Zeigt die EOL-Zeichen visuell an
                Editor.ViewWhitespace = WhitespaceMode.VisibleAlways;
            }

        }
        private async void btnFormat_Click(object sender, EventArgs e)
        {
            await FormatDocumentAsync();
        }
        private async void btnRebuild_Click(object sender, EventArgs e)
        {
            await HandleRebuildAsync();

        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveCode();
        }
        private async void btnReload_Click(object sender, EventArgs e)
        {
            Editor.Text = "";
            await LoadBook();

        }
        private void btnToggleTheme_Click(object sender, EventArgs e)
        {
            ToggleTheme();
        }
        private async void btnRun_Click(object sender, EventArgs e)
        {
            await DoRun();
        }
        private async void renameCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditorNode page = _selectedNode.PageNode;
            EditorNode code = _selectedNode;

            string pageName = Regex.Replace(page.Text, @"^[^_]*_", "");
            string codeName = Regex.Replace(code.Text, @"^[^_]*_", "").Replace(".cs", "");

            oPage edit = FindPageByName(pageName);

            string newName = codeName;
            if (!UiExtentions.ShowEditTextDialog(ref newName, "New name of the custom code:"))
                return;

            RenameSubCode(edit, codeName, newName);
            code.Text = $"{newName}";
          
            await LoadBook();
        }
        private void btnEditorOutput_Click(object sender, EventArgs e)
        {
            this.tableLayoutPanel3.Controls.Contains(this.dataGridBuild);
            this.tableLayoutPanel3.Controls.Remove(this.dataGridBuild);
            this.tableLayoutPanel3.Controls.Add(this.dataGridOutput, 1, 2);

            UpdateOutputButtons();

        }
        private void btnBuildOutput_Click(object sender, EventArgs e)
        {
            this.tableLayoutPanel3.Controls.Contains(this.dataGridOutput);
            this.tableLayoutPanel3.Controls.Remove(this.dataGridOutput);
            this.tableLayoutPanel3.Controls.Add(this.dataGridBuild, 1, 2);
            UpdateOutputButtons();
        }
        private void ProjectTree_AfterSelect(object sender, TreeViewEventArgs e)
        {
            ProjectTree.SelectedNode = null;
        }
        private void hidePageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            oPage page = FindPageByName(Regex.Replace(_selectedNode.Text, @"^[^_]*_", ""));

            page.Hidden = !page.Hidden;
            _selectedNode.ImageIndex = page.Hidden ? 4 : 2;
        }
        private void hidePageToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {

            //if (_lastClickedNode != null && _lastClickedNode.Tag is qbook.oPage)
            //    (_lastClickedNode.Tag as qbook.oPage).Hidden = (sender as ToolStripMenuItem).Checked;
            //UpdatePageTreeView(treeViewCodePages.Nodes);
        }
        private void toolStripMenuOpenWorkspace_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", RootNode.FilePath);

        }
        private void FormEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
        private async void addPageBeforeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewPageBelowSelectedPage(true);
            await LoadBook();
        }
        private void AddNewPageBelowSelectedPage(bool beforeSelectedPage = false)
        {
            qbook.Core.ThisBook.Modified = true;
            //qbook.Core.ActualMain = (sender as oIcon).Parent;

            string newName = "newPage";


        _AddPageStart:

            if (!UiExtentions.ShowEditTextDialog(ref newName, "Page name:"))
                return;


            bool pageNameExists = false;
            foreach (oPage page in qbook.Core.ActualMain.Objects.OfType<oPage>())
            {
                string newFullName = null;
                int index = page.FullName.LastIndexOf(".");
                if (index == -1)
                    newFullName = newName.Trim();
                else
                    newFullName = page.FullName.Substring(0, index) + newName.Trim();
                if (page.FullName == newFullName)
                {
                    pageNameExists = true;
                    break;
                }
            }
            if (pageNameExists)
            {
                MessageBox.Show($"A page with the name '{newName}' already exists.\r\nPlease choose a different name."
                    , "PAGE NAME EXISTS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                goto _AddPageStart;
            }

            oPage newPage = new oPage(newName, newName);

            //TODO: insert after selected page/node
            //int indx = (sender as oIcon).Parent.Objects.IndexOf(qbook.Core.SelectedPage);
            int indx = 0;
            if (SelectedPage == null)
                indx = 0;
            else
                indx = qbook.Core.ThisBook.Main.Objects.OfType<oPage>().ToList().IndexOf(SelectedPage);

            if (beforeSelectedPage)
                indx = indx + 0;
            else
                indx = indx + 1;

            qbook.Core.ThisBook.Main.Objects.Insert(indx, newPage);
            qbook.Core.SelectedPage = newPage;

            //   Main.Qb.SelectedLayer.Add(newItem);
            qbook.Core.ThisBook.Modified = true;
            //PopulatePageTreeView(false, true);

        }
        private async void addPageAfterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewPageBelowSelectedPage(false);
            await LoadBook();
        }
        private async void customToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode page = _selectedNode;
            Debug.WriteLine("Customizing page " + page.Text);
            string pageName = Regex.Replace(page.Text, @"^[^_]*_", ""); ;
            oPage edit = FindPageByName(pageName);

            string title = "CustomCode";

            if (!UiExtentions.ShowEditTextDialog(ref title, "Name of the custom code:"))
                return;

            Debug.WriteLine("Add costum code: " + title);


            if (!edit.CsCodeExtra.ContainsKey(title))
            {
                edit.CsCodeExtra[title] = "";
                await LoadBook();
            }
            else
            {
                MessageBox.Show("A custom code with this name already exists. Please choose a different name.");
            }
        }
        private async void deleteStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode page = _selectedNode.Parent;
            TreeNode code = _selectedNode;

            string pageName = Regex.Replace(page.Text, @"^[^_]*_", "");
            string codeName = Regex.Replace(code.Text, @"^[^_]*_", "").Replace(".cs", "");

            oPage edit = FindPageByName(pageName);

            if (edit.CsCodeExtra.ContainsKey(codeName))
            {

                DialogResult result = MessageBox.Show(
                    $"Delete {codeName}?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (result == DialogResult.Yes)
                {
                    edit.CsCodeExtra.Remove(codeName);
                    ProjectTree.Nodes.Remove(code);
                    await LoadBook();
                }

            }
            else
            {
                MessageBox.Show($"A custom code '{codeName}' with this name not found");
            }

        }

        //========================= Theme =============================

        public void UpdateTabs()
        {
            foreach (EditorTab tab in PanelTabs.Controls)
            {
                tab.BackColor = tab == _selectedNode.Tab ? Editor.Styles[Style.Default].BackColor : ProjectTree.BackColor;
                tab.ForeColor = ProjectTree.ForeColor;
            }
        }
        void UpdateOutputButtons()
        {
            bool isBuild = this.tableLayoutPanel3.Controls.Contains(this.dataGridBuild);
            bool isEditor = this.tableLayoutPanel3.Controls.Contains(this.dataGridOutput);

            btnBuildOutput.ForeColor = ProjectTree.ForeColor;
            btnEditorOutput.ForeColor = ProjectTree.ForeColor;

            if (_currentTheme == EditorTheme.Light)
            {

                Color sel = Color.FromArgb(220, 220, 220);
                Color usel = Color.FromArgb(190, 190, 190);
                btnEditorOutput.BackColor = isEditor ? sel : usel;
                btnBuildOutput.BackColor = isBuild ? sel : usel;
            }

            if (_currentTheme == EditorTheme.Dark)
            {
                Color sel = Color.FromArgb(70, 70, 70);
                Color usel = Color.FromArgb(50, 50, 50);
                btnEditorOutput.BackColor = isEditor ? sel : usel;
                btnBuildOutput.BackColor = isBuild ? sel : usel;
            }
        }
        Color ButtonForeColor = Color.Transparent;
        private void ApplyLightTheme()
        {
            _currentTheme = EditorTheme.Light;

            //Background

            Color _backColor = Color.FromArgb(230, 230, 230);

            panelSplttter1.BackColor = Color.FromArgb(180, 180, 180);
            panelSplitter2.BackColor = Color.FromArgb(180, 180, 180);
            panelSplitter3.BackColor = Color.FromArgb(180, 180, 180);
            panelSplitter4.BackColor = Color.FromArgb(180, 180, 180);

            vBarEditor.SetBackColor = _backColor;
            vBarEditor.SetForeColor = Color.FromArgb(180, 180, 180);

            vBarMethodes.SetBackColor = _backColor;
            vBarMethodes.SetForeColor = Color.FromArgb(180, 180, 180);

            hBarEditor.SetBackColor = _backColor;
            hBarEditor.SetForeColor = Color.FromArgb(180, 180, 180);


            DwmTitleBar.SetImmersiveDarkMode(this.Handle, enabled: false);
            tableLayoutPanel1.BackColor = _backColor;
            tableLayoutPanel3.BackColor = _backColor;
            Editor.BorderStyle = ScintillaNET.BorderStyle.None;

            //ProjectTree
            ProjectTree.BackColor = _backColor;
            ProjectTree.ForeColor = Color.Black;
            ProjectTree.BorderStyle = System.Windows.Forms.BorderStyle.None;
            UpdateAllNodes(ProjectTree, ProjectTree.ForeColor, 2, 2);
            //UpdateAllNodes(ProjectTree, ProjectTree.ForeColor, 2, 3);
            //UpdateAllNodes(ProjectTree, ProjectTree.ForeColor, 3, 4);
            ProjectTree.SelectedImageIndex = 10;
            if (_selectedNode != null)
                _selectedNode.ForeColor = Color.Purple;

            //Methodes
            lblMethodes.BackColor = _backColor;
            lblMethodes.ForeColor = ProjectTree.ForeColor;
            gridViewMethodes.BackgroundColor = _backColor;
            gridViewMethodes.BackColor = _backColor;
            gridViewMethodes.RowsDefaultCellStyle.BackColor = _backColor;
            gridViewMethodes.RowsDefaultCellStyle.ForeColor = ProjectTree.ForeColor;


            vBarMethodes.SetBackColor = _backColor;
            vBarMethodes.SetForeColor = Color.FromArgb(180, 180, 180);


            vBarProjectTree.SetBackColor = _backColor;
            vBarProjectTree.SetForeColor = Color.FromArgb(70, 70, 70);


            //Status
            labelStatus.BackColor = _backColor;
            labelStatus.ForeColor = ProjectTree.ForeColor;


            if (ButtonForeColor == Color.Transparent) ButtonForeColor = Color.Black;


            //PanelControl
            _backColor = Color.FromArgb(220, 220, 220);
            panelControl.BackColor = _backColor;

            foreach (System.Windows.Forms.Button b in panelControl.Controls)
            {
                b.BackColor = _backColor;
                //  b.Font = new Font("Segoe UI", 12, FontStyle.Bold);
                b.ForeColor = Color.Black;
                b.FlatAppearance.BorderColor = _backColor;
                Bitmap pic = b.Image as Bitmap;
                pic = BitmapTools.ReplaceColor(pic, Color.FromArgb(150, 150, 150), Color.FromArgb(100, 100, 100), 100);
                pic = BitmapTools.ResizeExact(pic, 28, 28);
                var old = b.Image;
                b.Image = pic;
                old?.Dispose(); ;
            }



            //Output
            UpdateOutputButtons();

            //Buttons
            _backColor = Color.FromArgb(230, 230, 230);
            foreach (System.Windows.Forms.Button b in panelFunctions.Controls)
            {
                b.BackColor = tableLayoutPanel1.BackColor;
                b.Font = new System.Drawing.Font("Segoe UI", 12, System.Drawing.FontStyle.Bold);
                b.ForeColor = System.Drawing.Color.Black;
                b.FlatAppearance.BorderColor = _backColor;
                Bitmap pic = b.Image as Bitmap;
                pic = BitmapTools.ReplaceColor(pic, Color.White, Color.Black);
                pic = BitmapTools.ResizeExact(pic, 32, 32);
                var old = b.Image;
                b.Image = pic;
                old?.Dispose();
            }

            ButtonForeColor = Color.Black;
            dataGridOutput.BackgroundColor = Color.FromArgb(220, 220, 220);
            dataGridBuild.BackgroundColor = Color.FromArgb(220, 220, 220);
            _currentTheme = EditorTheme.Light;
            // Grundstil (Visual Studio Light / VS Code Light+ nahe)
            Editor.StyleResetDefault();
            Editor.Styles[Style.Default].Font = "Cascadia Code";
            Editor.Styles[Style.Default].Size = 10;
            Editor.Styles[Style.Default].BackColor = Color.White;                // Editor Hintergrund
            Editor.Styles[Style.Default].ForeColor = Color.Black;                // Standard Text
            Editor.StyleClearAll();
            Editor.CaretForeColor = Color.Black;
            Editor.SetSelectionBackColor(true, Color.FromArgb(0xD7, 0xE4, 0xF2)); // Standard VS Light Selektionsblau ähnlich
            Editor.WhitespaceSize = 2;
            Editor.ViewWhitespace = WhitespaceMode.Invisible;

            // Brace Highlight (angepasst an VS Light – leicht gelblicher Hintergrund)
            Editor.Styles[Style.BraceLight].ForeColor = Color.Black;
            Editor.Styles[Style.BraceLight].BackColor = Color.FromArgb(0xFF, 0xF4, 0xC1);
            Editor.Styles[Style.BraceBad].ForeColor = Color.White;
            Editor.Styles[Style.BraceBad].BackColor = Color.FromArgb(0xE5, 0x51, 0x51);

            // Folding Marker Farben (neutral grau wie VS)
            var foldFore = Color.FromArgb(0x80, 0x80, 0x80);
            var foldBack = foldFore;
            for (int i = Marker.FolderEnd; i <= Marker.FolderOpenMid; i++)
            {
                Editor.Markers[i].SetForeColor(foldFore);
                Editor.Markers[i].SetBackColor(foldBack);
            }

            // Visual Studio Light / VS Code Light+ typische Farben:
            // Keywords: #0000FF
            // Strings: #A31515
            // Comments: #008000
            // Numbers: #098658
            // Method: #795E26
            // Types (Class/Struct/Interface/Enum): #267F99 (annähernd #2B91AF aus altem VS; etwas entsättigt für moderne Light Themes)
            // Property: #001080
            // Field: #D4D4D4 (Standard)

            Color vsKeyword = Color.FromArgb(0x00, 0x00, 0xFF);   // Blau
            Color vsString = Color.FromArgb(0xA3, 0x15, 0x15);    // Dunkelrot
            Color vsComment = Color.FromArgb(0x00, 0x80, 0x00);   // Grün
            Color vsNumber = Color.FromArgb(0x09, 0x86, 0x58);    // Grünlich
            Color vsMethod = Color.FromArgb(0x79, 0x5E, 0x26);    // Braun
            Color vsType = Color.FromArgb(0x26, 0x7F, 0x99);      // Cyan / Type
            Color vsProperty = Color.FromArgb(0x00, 0x10, 0x80);  // Dunkelblau
            Color Commands = Color.FromArgb(183, 0, 219);
            Color NameSpaceName = Color.FromArgb(0x26, 0x7F, 0x99);

            // Errors (bleibt Rot)
            Editor.Indicators[0].ForeColor = Color.Red;
            // Methoden
            Editor.Indicators[2].ForeColor = vsMethod;
            // Klassen
            Editor.Indicators[3].ForeColor = vsType;
            // Interfaces
            Editor.Indicators[4].ForeColor = vsType;
            // Structs
            Editor.Indicators[5].ForeColor = vsType;
            // Enums
            Editor.Indicators[6].ForeColor = vsType;
            // Delegates (wie Methoden leicht abheben)
            Editor.Indicators[7].ForeColor = vsMethod;
            // Properties
            Editor.Indicators[8].ForeColor = vsProperty;
            // Fields
            Editor.Indicators[9].ForeColor = Color.Black;
            // Keywords
            Editor.Indicators[10].ForeColor = vsKeyword;
            // Numbers
            Editor.Indicators[11].ForeColor = vsNumber;
            // Strings
            Editor.Indicators[12].ForeColor = vsString;
            // Comments
            Editor.Indicators[13].ForeColor = vsComment;

            //Commands
            Editor.Indicators[14].ForeColor = Commands;

            //NameSpace
            Editor.Indicators[15].ForeColor = NameSpaceName;

            // Caret Line
            Editor.CaretLineVisible = true;
            Editor.CaretLineBackColor = Color.FromArgb(0xF3, 0xF9, 0xFF);

            // Line Numbers / Folding Ränder
            Editor.Styles[Style.LineNumber].BackColor = Color.White;
            Editor.SetFoldMarginColor(true, Color.White);
            Editor.SetFoldMarginHighlightColor(true, Color.White);
            InitializeFolding();

            //Error Style
            int STYLE_ERROR = 20;
            Editor.Styles[STYLE_ERROR].BackColor = Color.Red;
            Editor.Styles[STYLE_ERROR].ForeColor = Color.White; // optional

            // Autocomplete Farben
            Editor.AutocompleteListBackColor = Color.White;
            Editor.AutocompleteListTextColor = Color.Black;

            UpdateTabs();
        }
        private void ApplyDarkTheme()
        {
            _currentTheme = EditorTheme.Dark;
            Color _backColor = Color.FromArgb(40, 40, 40);

            panelSplttter1.BackColor = Color.FromArgb(70, 70, 70);
            panelSplitter2.BackColor = Color.FromArgb(70, 70, 70);
            panelSplitter3.BackColor = Color.FromArgb(70, 70, 70);
            panelSplitter4.BackColor = Color.FromArgb(70, 70, 70);


            //Background
            DwmTitleBar.SetImmersiveDarkMode(this.Handle, enabled: true);

            tableLayoutPanel1.BackColor = _backColor;
            tableLayoutPanel3.BackColor = _backColor;
            Editor.BorderStyle = ScintillaNET.BorderStyle.None;

            vBarEditor.SetBackColor = _backColor;
            vBarEditor.SetForeColor = Color.FromArgb(70, 70, 70);
            vBarMethodes.SetBackColor = _backColor;
            vBarMethodes.SetForeColor = Color.FromArgb(70, 70, 70);
            hBarEditor.SetBackColor = _backColor;
            hBarEditor.SetForeColor = Color.FromArgb(70, 70, 70);

            vBarProjectTree.SetBackColor = _backColor;
            vBarProjectTree.SetForeColor = Color.FromArgb(70, 70, 70);

            //ProjectTree
            ProjectTree.BackColor = _backColor;
            ProjectTree.ForeColor = Color.FromArgb(190, 190, 190);
            ProjectTree.BorderStyle = System.Windows.Forms.BorderStyle.None;
            ProjectTree.SelectedImageIndex = 10;

            UpdateAllNodes(ProjectTree, ProjectTree.ForeColor, 1, 1);
            //UpdateAllNodes(ProjectTree, ProjectTree.ForeColor, 2, 3);
            //UpdateAllNodes(ProjectTree, ProjectTree.ForeColor, 3, 4);

            //Methodes
            lblMethodes.BackColor = _backColor;
            lblMethodes.ForeColor = ProjectTree.ForeColor;
            gridViewMethodes.BackgroundColor = _backColor;
            gridViewMethodes.BackColor = _backColor;
            gridViewMethodes.RowsDefaultCellStyle.BackColor = _backColor;
            gridViewMethodes.RowsDefaultCellStyle.ForeColor = ProjectTree.ForeColor;

            if (_selectedNode != null)
                _selectedNode.ForeColor = Color.Plum;

            //Status
            labelStatus.BackColor = _backColor;
            labelStatus.ForeColor = ProjectTree.ForeColor;


            //PanelControl
            _backColor = Color.FromArgb(60, 60, 60);
            panelControl.BackColor = _backColor;

            foreach (System.Windows.Forms.Button b in panelControl.Controls)
            {
                b.BackColor = _backColor;

                b.ForeColor = Color.FromArgb(200, 200, 200);
                b.FlatAppearance.BorderColor = _backColor;
                Bitmap pic = b.Image as Bitmap;
                pic = BitmapTools.ReplaceColor(pic, Color.Black, Color.FromArgb(190, 190, 190), 100);
                //  pic = BitmapTools.ResizeExact(pic, 28, 28);
                var old = b.Image;
                b.Image = pic;
                old?.Dispose();
            }


            //Buttons
            _backColor = Color.FromArgb(40, 40, 40);
            if (ButtonForeColor == Color.Transparent) ButtonForeColor = Color.White;

            foreach (System.Windows.Forms.Button b in panelFunctions.Controls)
            {
                b.BackColor = _backColor;
                b.Font = new Font("Segoe UI", 12, FontStyle.Bold);
                b.ForeColor = Color.Black;
                b.FlatAppearance.BorderColor = _backColor;
                Bitmap pic = b.Image as Bitmap;
                pic = BitmapTools.ReplaceColor(pic, ButtonForeColor, Color.FromArgb(120, 120, 120));
                //    pic = BitmapTools.ResizeExact(pic, 32, 32);
                var old = b.Image;
                b.Image = pic;
                old?.Dispose();
            }
            ButtonForeColor = Color.FromArgb(120, 120, 120);

            //Outputs
            UpdateOutputButtons();
            dataGridOutput.BackgroundColor = Color.FromArgb(70, 70, 70);
            dataGridOutput.ForeColor = Color.Black;

            dataGridBuild.BackgroundColor = Color.FromArgb(70, 70, 70);
            dataGridBuild.ForeColor = Color.Black;

            //



            _currentTheme = EditorTheme.Dark;
            // Grundstil (Visual Studio Dark / VS Code Dark+)
            Editor.StyleResetDefault();
            Editor.Styles[Style.Default].Font = "Cascadia Code";
            Editor.Styles[Style.Default].Size = 10;
            Editor.Styles[Style.Default].BackColor = Color.FromArgb(25, 25, 25);          // #1E1E1E
            Editor.Styles[Style.Default].ForeColor = Color.FromArgb(200, 200, 200);          // Standard Text
            Editor.StyleClearAll();
            Editor.CaretForeColor = Color.White;
            Editor.SetSelectionBackColor(true, Color.FromArgb(0x26, 0x4F, 0x78));               // Auswahlblau dunkel
            Editor.WhitespaceSize = 2;
            Editor.ViewWhitespace = WhitespaceMode.Invisible;

            // Brace Highlight (VS Dark ähnlich)
            Editor.Styles[Style.BraceLight].ForeColor = Color.FromArgb(0xFF, 0xC0, 0x40);
            Editor.Styles[Style.BraceLight].BackColor = Color.FromArgb(0x33, 0x33, 0x33);
            Editor.Styles[Style.BraceBad].ForeColor = Color.White;
            Editor.Styles[Style.BraceBad].BackColor = Color.FromArgb(0x90, 0x2B, 0x2B);

            // Folding Marker (leicht kontrastreich)
            var foldFore = Color.FromArgb(0xAA, 0xAA, 0xAA);
            var foldBack = Color.FromArgb(0x2D, 0x2D, 0x2D);
            for (int i = Marker.FolderEnd; i <= Marker.FolderOpenMid; i++)
            {
                Editor.Markers[i].SetForeColor(foldFore);
                Editor.Markers[i].SetBackColor(foldBack);
            }

            // VS Dark / VS Code Dark+ Referenzfarben:
            // Keyword: #569CD6
            // String: #CE9178
            // Comment: #6A9955
            // Number: #B5CEA8
            // Method: #DCDCAA
            // Class: #4EC9B0
            // Interface: #B8D7A3
            // Struct: #86C691
            // Enum: #B8D7A3
            // Delegate: #DCDCAA (wie Method)
            // Property: #9CDCFE
            // Field: #D4D4D4 (Standard)

            Color vsDarkKeyword = Color.FromArgb(0x56, 0x9C, 0xD6);
            Color vsDarkString = Color.FromArgb(0xCE, 0x91, 0x78);
            Color vsDarkComment = Color.FromArgb(84, 153, 85);
            Color vsDarkNumber = Color.FromArgb(0xB5, 0xCE, 0xA8);
            Color vsDarkMethod = Color.FromArgb(0xDC, 0xDC, 0xAA);
            Color vsDarkClass = Color.FromArgb(0x4E, 0xC9, 0xB0);
            Color vsDarkInterface = Color.FromArgb(0xB8, 0xD7, 0xA3);
            Color vsDarkStruct = Color.FromArgb(0x86, 0xC6, 0x91);
            Color vsDarkEnum = Color.FromArgb(0xB8, 0xD7, 0xA3);
            Color vsDarkDelegate = vsDarkMethod;
            Color vsDarkProperty = Color.FromArgb(0x9C, 0xDC, 0xFE);
            Color vsDarkField = Color.FromArgb(0xD4, 0xD4, 0xD4);
            Color Commands = Color.FromArgb(216, 160, 215);
            Color NameSpaceName = vsDarkClass;

            // Errors
            Editor.Indicators[0].ForeColor = Color.FromArgb(0xF4, 0x43, 0x36);
            // Methoden
            Editor.Indicators[2].ForeColor = vsDarkMethod;
            // Klassen
            Editor.Indicators[3].ForeColor = vsDarkClass;
            // Interfaces
            Editor.Indicators[4].ForeColor = vsDarkInterface;
            // Structs
            Editor.Indicators[5].ForeColor = vsDarkStruct;
            // Enums
            Editor.Indicators[6].ForeColor = vsDarkEnum;
            // Delegates
            Editor.Indicators[7].ForeColor = vsDarkDelegate;
            // Properties
            Editor.Indicators[8].ForeColor = vsDarkProperty;
            // Fields
            Editor.Indicators[9].ForeColor = vsDarkField;
            // Keywords
            Editor.Indicators[10].ForeColor = vsDarkKeyword;
            // Numbers
            Editor.Indicators[11].ForeColor = vsDarkNumber;
            // Strings
            Editor.Indicators[12].ForeColor = vsDarkString;
            // Comments
            Editor.Indicators[13].ForeColor = vsDarkComment;

            //Commands
            Editor.Indicators[14].ForeColor = Commands;
            //NameSpace
            Editor.Indicators[15].ForeColor = NameSpaceName;

            Editor.CaretLineVisible = true;
            Editor.CaretLineBackColor = Color.FromArgb(0x2A, 0x2A, 0x2A);

            if (_searchBar.Visible) _searchBar.DarkTheme();

            // Line Numbers & Folding
            Editor.Styles[Style.LineNumber].BackColor = Color.FromArgb(25, 25, 25); ;
            Editor.SetFoldMarginColor(true, Color.FromArgb(25, 25, 25));
            Editor.SetFoldMarginHighlightColor(true, Color.FromArgb(25, 25, 25));
            InitializeFolding();

            // Autocomplete
            Editor.AutocompleteListBackColor = Color.FromArgb(0x25, 0x25, 0x25);
            Editor.AutocompleteListTextColor = Color.FromArgb(0xD4, 0xD4, 0xD4);

            UpdateTabs();
        }
        public void ToggleTheme()
        {
            if (_currentTheme == EditorTheme.Light) ApplyDarkTheme(); else ApplyLightTheme();
            RefreshSemanticOverlaysAsync();
            if (_currentTheme == EditorTheme.Dark) _searchBar.DarkTheme(); else _searchBar.LightTheme();
            if (_currentTheme == EditorTheme.Dark) _replaceBar?.DarkTheme(); else _replaceBar?.LightTheme();
        }

        private void toolStripMenuIncludeCode_Click(object sender, EventArgs e)
        {
            if (_clickedNode == null) return;

            if (_clickedNode.Active)
            {
                ExcludeCode(_clickedNode);
                _clickedNode.ImageIndex = 5;
            }
            else
            {
                IncludeCode(_clickedNode);
                _clickedNode.ImageIndex = 3;
            }
        }
    }

    public class EditorTab : System.Windows.Forms.Button
    {

    
        FormEditor Root;

        EditorNode Node;
        internal EditorTab(EditorNode node, FormEditor root)
        {
            Node = node;
            Root = root;

            string name = node.Text;


            if (node.Type == EditorNode.NodeType.SubCode)
                name = node.PageNode.Text + "." + node.Text;


            BackColor = System.Drawing.Color.LightGray;
            Dock = System.Windows.Forms.DockStyle.Left;
            FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            FlatAppearance.BorderSize = 0;
            FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Location = new System.Drawing.Point(87, 0);
            Margin = new System.Windows.Forms.Padding(0);
            Name = node.Name;
            var textSize = System.Windows.Forms.TextRenderer.MeasureText(name, Font);
            Size = new System.Drawing.Size(textSize.Width + 20, 25);
            TabIndex = 1;
            Text = name;
            UseVisualStyleBackColor = false;
            Click += new EventHandler((sender, e) => JumpToPosition());


            MouseUp += (sender, e) =>
            {
                if (e.Button == MouseButtons.Right)
                {
                    Remove();
                }
            };


        }

        public void JumpToPosition()
        {
            Root.OpendNode(Node);
            Root.Editor.Focus();

            Root.UpdateTabs();


        }

        public void Remove()
        {
            if (Root.PanelTabs.Controls.Count == 1) 
            {
                Root.ResetCurrentFile();
                Root.Editor.Text = "";
            }
            Root.PanelTabs.Controls.Remove(this);
        }
    }




    internal static class DwmTitleBar
    {
        // DWMWINDOWATTRIBUTE Werte (Windows 11+)
        private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20; // (19 bei älteren Win10-Insider Builds)
        private const int DWMWA_BORDER_COLOR = 34;
        private const int DWMWA_CAPTION_COLOR = 35;
        private const int DWMWA_TEXT_COLOR = 36;


        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);


        public static bool IsWindows11OrNewer()
        {
            // Windows 11: Build >= 22000
            try { return Environment.OSVersion.Version.Build >= 22000; } catch { return false; }
        }


        public static bool SetImmersiveDarkMode(IntPtr hwnd, bool enabled)
        {
            int v = enabled ? 1 : 0;
            int hr = DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, ref v, sizeof(int));
            return hr >= 0; // S_OK = 0; negative = Fehler
        }


        public static bool SetCaptionColor(IntPtr hwnd, Color color)
        {
            // COLORREF (BGR) – ColorTranslator.ToWin32 liefert korrektes Format
            int colorRef = ColorTranslator.ToWin32(color);
            int hr = DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, ref colorRef, sizeof(int));
            return hr >= 0;
        }


        public static bool SetTextColor(IntPtr hwnd, Color color)
        {
            int colorRef = ColorTranslator.ToWin32(color);
            int hr = DwmSetWindowAttribute(hwnd, DWMWA_TEXT_COLOR, ref colorRef, sizeof(int));
            return hr >= 0;
        }


        public static bool SetBorderColor(IntPtr hwnd, Color color)
        {
            int colorRef = ColorTranslator.ToWin32(color);
            int hr = DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR, ref colorRef, sizeof(int));
            return hr >= 0;
        }
    }

}
