﻿using Microsoft.Build.Locator;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Classification;
using Microsoft.CodeAnalysis.Completion;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.FindSymbols;
using Microsoft.CodeAnalysis.Formatting;
using Microsoft.CodeAnalysis.Host;
using Microsoft.CodeAnalysis.Host.Mef;
using Microsoft.CodeAnalysis.MSBuild;
using Microsoft.CodeAnalysis.Rename;
using Microsoft.CodeAnalysis.Text;
using Microsoft.VisualStudio.SolutionPersistence.Model;
using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AccessibilityCode = Microsoft.CodeAnalysis.Accessibility;
using RoslynDocument = Microsoft.CodeAnalysis.Document; // Alias gegen Kollision mit ScintillaNET.Document

namespace qbook.CodeEditor
{
    public sealed partial class RoslynServices
    {

        private MSBuildWorkspace? _ws;
        private Project? _project;
        private readonly SemaphoreSlim _loadSemaphore = new(1, 1);
        private bool _isLoading;
        public bool IsProjectLoaded => _project != null;
        public async Task LoadProjectAsync(string csprojPath)
        {
            QB.Logger.Debug("LoadProjectAsync: '" + csprojPath + "'");

            if (string.IsNullOrWhiteSpace(csprojPath) || !File.Exists(csprojPath)) return;
            await _loadSemaphore.WaitAsync(); 
            try 
            { if (_project != null || _isLoading) return; 
                _isLoading = true; 
                if (!MSBuildLocator.IsRegistered) 
                { 
                    try 
                    { var instances = MSBuildLocator.QueryVisualStudioInstances().ToArray();
                        if 
                            (instances.Length > 0) MSBuildLocator.RegisterInstance(instances.OrderByDescending(i => i.Version).First());
                        else 
                            MSBuildLocator.RegisterDefaults(); 
                    } 
                    catch (Exception ex) 
                    { 
                        Debug.WriteLine("MSBuildLocator registration failed: " + ex.Message); 
                        QB.Logger.Error("[RoslynServices]: LoadProjectAsync MSBuildLocator registration failed: " + ex.Message);
                    } 
                } 
                var props = new Dictionary<string, string> { { "DesignTimeBuild", "true" }, { "BuildingInsideVisualStudio", "true" } };



                _ws = MSBuildWorkspace.Create(props);

                _ws.WorkspaceFailed += (s, e) => QB.Logger.Error($"[WorkspaceFailed] {e.Diagnostic.Kind}: {e.Diagnostic.Message}"); 
                try 
                { 
                    _project = await _ws.OpenProjectAsync(csprojPath); 
                } 
                catch (Exception ex) 
                {
                    QB.Logger.Error("OpenProjectAsync failed: " + ex.Message); 
                    _project = null; 
                } 
            } 
            finally 
            { 
                _isLoading = false;
                _loadSemaphore.Release(); 
            }
        }

        public void Reset()
        {
            if (_ws != null)
            {
                try { _ws.Dispose(); } catch { }
                _ws = null;
                _project = null;
            }
        }


        private RoslynDocument? FindDocument(string filePath)
        {
           QB.Logger.Debug("FindDocument: '" + filePath + "'" );

            return _ws?.CurrentSolution.Projects.SelectMany(p => p.Documents).FirstOrDefault(d => string.Equals(d.FilePath, filePath, StringComparison.OrdinalIgnoreCase));
        }
        public RoslynDocument? GetDocument(string filePath)
        {
            QB.Logger.Debug("GetDocument: '" + filePath + "'");
            return FindDocument(filePath);
        }
        public async Task UpdateOpenDocumentAsync(string filePath, string text)
        {
           QB.Logger.Debug("UpdateOpenDocumentAsync: '" + filePath + "'");
            if (_ws == null || string.IsNullOrWhiteSpace(filePath)) return;
            try
            {
                var doc = FindDocument(filePath);
                if (doc is null && _project != null)
                {
                    var docIdNew = DocumentId.CreateNewId(_project.Id);
                    var newSolution = _ws.CurrentSolution.AddDocument(docIdNew, Path.GetFileName(filePath), SourceText.From(text), filePath: filePath);
                    _ws.TryApplyChanges(newSolution);
                }
                else if (doc is not null)
                {
                    var newDoc = doc.WithText(SourceText.From(text));
                    _ws.TryApplyChanges(newDoc.Project.Solution);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("UpdateOpenDocumentAsync error: " + ex.Message);
            }
        }
        public async Task<(CompletionItem[] items, int start)> GetCompletionsAsync(string filePath, string text, int caret)
        {
            QB.Logger.Debug("GetCompletionsAsync: '" + filePath + "', caret=" + caret);
            if (_ws == null || _project == null) return (Array.Empty<CompletionItem>(), caret); await UpdateOpenDocumentAsync(filePath, text); var doc = FindDocument(filePath); if (doc is null) return (Array.Empty<CompletionItem>(), caret); try { var service = CompletionService.GetService(doc); if (service == null) return (Array.Empty<CompletionItem>(), caret); var triggerChar = caret > 0 && caret <= text.Length ? text[caret - 1] : ' '; var results = await service.GetCompletionsAsync(doc, caret, trigger: CompletionTrigger.CreateInsertionTrigger(triggerChar)); if (results == null) return (Array.Empty<CompletionItem>(), caret); return (results.ItemsList.ToArray(), results.Span.Start); } catch (Exception ex) { Debug.WriteLine("GetCompletionsAsync error: " + ex.Message); return (Array.Empty<CompletionItem>(), caret); }
        }
        public async Task<(string FilePath, int Line, int Column)?> GoToDefinitionAsync(string filePath, string text, int caret)
        {
            if (_ws == null) return null; await UpdateOpenDocumentAsync(filePath, text); var doc = FindDocument(filePath); if (doc == null) return null; try { var semantic = await doc.GetSemanticModelAsync(); var tree = await doc.GetSyntaxTreeAsync(); if (semantic == null || tree == null) return null; var root = await tree.GetRootAsync(); var token = root.FindToken(Math.Max(0, caret - 1)); var symbol = semantic.GetSymbolInfo(token.Parent!).Symbol ?? semantic.GetDeclaredSymbol(token.Parent!); if (symbol == null) return null; var def = await SymbolFinder.FindSourceDefinitionAsync(symbol, _ws.CurrentSolution) ?? symbol; var loc = def.Locations.FirstOrDefault(l => l.IsInSource); if (loc == null) return null; var linePos = loc.GetLineSpan().StartLinePosition; return (loc.SourceTree!.FilePath!, linePos.Line, linePos.Character); } catch (Exception ex) { Debug.WriteLine("GoToDefinitionAsync error: " + ex.Message); return null; }
        }
        public async Task<Dictionary<string, string>?> RenameSymbolAsync(string filePath, string text, int caret, string newName)
        {
            if (_ws == null || string.IsNullOrWhiteSpace(newName)) return null;
            try
            {

                await UpdateOpenDocumentAsync(filePath, text);
                var doc = FindDocument(filePath);
                if (doc is null) return null;
                var semantic = await doc.GetSemanticModelAsync();
                var tree = await doc.GetSyntaxTreeAsync();
                if (semantic == null || tree == null) return null;
                var root = await tree.GetRootAsync();

                // Robust token retrieval (caret might be at end of identifier)
                int pos = Math.Min(Math.Max(caret - 1, 0), root.FullSpan.End - 1);
                var token = root.FindToken(pos);

                ISymbol? symbol = null;
                SyntaxNode? current = token.Parent;

                // Try lookup symbol info on ascending nodes
                while (current != null && symbol == null)
                {
                    symbol = semantic.GetSymbolInfo(current).Symbol ?? semantic.GetDeclaredSymbol(current);
                    current = current.Parent;
                }
                if (symbol == null) return null;
                if (string.Equals(symbol.Name, newName, StringComparison.Ordinal)) return new Dictionary<string, string>();

                var solution = _ws.CurrentSolution;
                Solution newSolution;
                try
                {
                    newSolution = await Renamer.RenameSymbolAsync(solution, symbol, newName, _ws.Options);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Renamer.RenameSymbolAsync failed: " + ex.Message);
                    return null;
                }
                if (ReferenceEquals(solution, newSolution)) return null;

                var changes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var proj in newSolution.Projects)
                {
                    foreach (var d in proj.Documents)
                    {
                        var oldDoc = solution.GetDocument(d.Id);
                        if (oldDoc == null) continue;
                        var newTextSource = await d.GetTextAsync();
                        var oldTextSource = await oldDoc.GetTextAsync();
                        if (!newTextSource.ContentEquals(oldTextSource))
                        {
                            if (!string.IsNullOrEmpty(d.FilePath))
                                changes[d.FilePath!] = newTextSource.ToString();
                        }
                    }
                }

                if (changes.Count == 0) return null;
                if (!_ws.TryApplyChanges(newSolution))
                {
                    Debug.WriteLine("TryApplyChanges failed after rename.");
                }
                return changes;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("RenameSymbolAsync error (outer): " + ex.Message);
                return null;
            }
        }
        public async Task<IReadOnlyList<string>> LookupInstanceMemberNamesAsync(string filePath, string text, int position)
        {
            var names = new HashSet<string>(StringComparer.Ordinal);
            if (_ws == null || _project == null) return names.ToList();
            await UpdateOpenDocumentAsync(filePath, text);
            var doc = FindDocument(filePath);
            if (doc == null) return names.ToList();
            var semantic = await doc.GetSemanticModelAsync();
            var root = await doc.GetSyntaxRootAsync();
            if (semantic == null || root == null) return names.ToList();
            var token = root.FindToken(Math.Min(position, root.FullSpan.End - 1));
            var node = token.Parent;
            INamedTypeSymbol? typeSym = null;
            while (node != null && typeSym == null)
            {
                if (node is TypeDeclarationSyntax tds) typeSym = semantic.GetDeclaredSymbol(tds) as INamedTypeSymbol;
                node = node.Parent;
            }
            if (typeSym == null) return names.ToList();
            foreach (var sym in semantic.LookupSymbols(position).Where(s => !s.IsStatic && s.ContainingType != null))
            {
                var ct = sym.ContainingType;
                bool inHierarchy = ct != null && (SymbolEqualityComparer.Default.Equals(ct, typeSym) || IsBaseOf(typeSym, ct));
                if (!inHierarchy) continue;
                switch (sym)
                {
                    case IMethodSymbol ms when ms.MethodKind == MethodKind.Ordinary: names.Add(ms.Name); break;
                    case IPropertySymbol ps: names.Add(ps.Name); break;
                    case IFieldSymbol fs when !fs.IsImplicitlyDeclared && !fs.Name.StartsWith("<"): names.Add(fs.Name); break;
                    case IEventSymbol es: names.Add(es.Name); break;
                }
            }
            return names.ToList();
            static bool IsBaseOf(INamedTypeSymbol derived, INamedTypeSymbol candidate)
            {
                var b = derived.BaseType;
                while (b != null)
                {
                    if (SymbolEqualityComparer.Default.Equals(b, candidate)) return true;
                    b = b.BaseType;
                }
                return false;
            }
        }
        public async Task<IReadOnlyList<string>> EnumerateHierarchyInstanceMembersAsync(string filePath, string text, int position)
        {
            var names = new HashSet<string>(StringComparer.Ordinal);
            if (_ws == null || _project == null) return names.ToList();
            await UpdateOpenDocumentAsync(filePath, text);
            var doc = FindDocument(filePath);
            if (doc == null) return names.ToList();
            var semantic = await doc.GetSemanticModelAsync();
            var root = await doc.GetSyntaxRootAsync();
            if (semantic == null || root == null) return names.ToList();
            var token = root.FindToken(Math.Min(position, root.FullSpan.End - 1));
            var node = token.Parent;
            INamedTypeSymbol? typeSym = null;
            while (node != null && typeSym == null)
            {
                if (node is TypeDeclarationSyntax tds)
                    typeSym = semantic.GetDeclaredSymbol(tds) as INamedTypeSymbol;
                node = node?.Parent;
            }
            if (typeSym == null) return names.ToList();
            void Add(INamedTypeSymbol t)
            {
                foreach (var member in t.GetMembers())
                {
                    if (member.IsImplicitlyDeclared) continue;
                    if (member.IsStatic) continue;
                    if (member.DeclaredAccessibility == AccessibilityCode.Private && !SymbolEqualityComparer.Default.Equals(t, typeSym)) continue;
                    switch (member)
                    {
                        case IPropertySymbol p: names.Add(p.Name); break;
                        case IFieldSymbol f when !f.Name.StartsWith("<"): names.Add(f.Name); break;
                        case IMethodSymbol m when m.MethodKind == MethodKind.Ordinary: names.Add(m.Name); break;
                        case IEventSymbol e: names.Add(e.Name); break;
                    }
                }
            }
            for (var t = typeSym; t != null && t.SpecialType != SpecialType.System_Object; t = t.BaseType)
                Add(t);
            return names.ToList();
        }
        public async Task<IReadOnlyList<string>> FindTypeCandidatesAsync(string filePath, string text, string prefix)
        {
            var list = new HashSet<string>(StringComparer.Ordinal);
            if (_ws == null || _project == null || string.IsNullOrWhiteSpace(prefix)) return list.ToList();
            await UpdateOpenDocumentAsync(filePath, text);
            var doc = FindDocument(filePath);
            if (doc == null) return list.ToList();
            var root = await doc.GetSyntaxRootAsync();
            var semantic = await doc.GetSemanticModelAsync();
            if (root == null || semantic == null) return list.ToList();

            string currentNs = "";
            var nsDecl = root.DescendantNodes().OfType<FileScopedNamespaceDeclarationSyntax>().FirstOrDefault();
            if (nsDecl != null)
                currentNs = nsDecl.Name.ToString();
            else
            {
                var blockNs = root.DescendantNodes().OfType<NamespaceDeclarationSyntax>().FirstOrDefault();
                if (blockNs != null) currentNs = blockNs.Name.ToString();
            }

            var fileUsings = root.DescendantNodes().OfType<UsingDirectiveSyntax>()
                                  .Select(u => u.Name.ToString())
                                  .ToHashSet(StringComparer.Ordinal);

            var compilation = semantic.Compilation;
            void VisitNamespace(INamespaceSymbol ns)
            {
                foreach (var member in ns.GetMembers())
                {
                    if (member is INamespaceSymbol childNs)
                    {
                        VisitNamespace(childNs);
                    }
                    else if (member is INamedTypeSymbol typeSym)
                    {
                        if (typeSym.Name.Length == 0) continue;
                        if (!typeSym.Name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
                        if (typeSym.TypeKind == TypeKind.Error) continue;
                        if (typeSym.DeclaredAccessibility is not (AccessibilityCode.Public or AccessibilityCode.Internal)) continue;
                        if (typeSym.DeclaredAccessibility == AccessibilityCode.Internal && !SymbolEqualityComparer.Default.Equals(typeSym.ContainingAssembly, compilation.Assembly))
                            continue;
                        var typeNs = typeSym.ContainingNamespace?.ToDisplayString() ?? string.Empty;
                        string shortName = typeSym.Name;
                        string fullyQualified = typeSym.ToDisplayString(SymbolDisplayFormat.FullyQualifiedFormat).Replace("global::", string.Empty);
                        if (string.Equals(typeNs, currentNs, StringComparison.Ordinal) || string.IsNullOrEmpty(typeNs))
                        {
                            list.Add(shortName);
                        }
                        else
                        {
                            bool imported = fileUsings.Contains(typeNs);
                            if (imported) list.Add(shortName); // allow short name because namespace imported
                            string minimal = typeNs + "." + shortName;
                            list.Add(minimal);
                            list.Add(fullyQualified);
                        }
                    }
                }
            }
            VisitNamespace(compilation.GlobalNamespace);
            return list.ToList();
        }

        public async Task<string?> AddUsingIfUniqueTypeAsync(string filePath, string text, string typeName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(typeName) || _ws == null || _project == null) return null;
                await UpdateOpenDocumentAsync(filePath, text);
                var doc = FindDocument(filePath);
                if (doc == null) return null;
                var semantic = await doc.GetSemanticModelAsync();
                var root = await doc.GetSyntaxRootAsync() as CSharpSyntaxNode;
                if (semantic == null || root == null) return null;
                // Already resolvable?
                var existing = semantic.LookupNamespacesAndTypes(root.FullSpan.Start, name: typeName);
                if (existing.Any(sym => sym is INamedTypeSymbol)) return null; // already available
                // Collect candidate types (public/internal) by traversing namespaces
                var compilation = semantic.Compilation;
                var candidates = new List<INamedTypeSymbol>();
                void VisitNamespace(INamespaceSymbol ns)
                {
                    foreach (var m in ns.GetMembers())
                    {
                        if (m is INamespaceSymbol child) VisitNamespace(child);
                        else if (m is INamedTypeSymbol t && t.Name.Equals(typeName, StringComparison.Ordinal))
                        {
                            if (t.DeclaredAccessibility is AccessibilityCode.Public or AccessibilityCode.Internal)
                            {
                                if (t.DeclaredAccessibility == AccessibilityCode.Internal && !SymbolEqualityComparer.Default.Equals(t.ContainingAssembly, compilation.Assembly)) continue;
                                candidates.Add(t);
                            }
                        }
                    }
                }
                VisitNamespace(compilation.GlobalNamespace);
                if (candidates.Count != 1) return null; // only auto if unique
                var target = candidates[0];
                var nsName = target.ContainingNamespace?.ToDisplayString() ?? string.Empty;
                if (string.IsNullOrEmpty(nsName)) return null;
                // Already has using?
                if (root.DescendantNodes().OfType<UsingDirectiveSyntax>().Any(u => u.Name.ToString() == nsName)) return null;
                // Insert using (keep at top, after existing usings, before namespace/type decl)
                var usingDirective = SyntaxFactory.UsingDirective(SyntaxFactory.ParseName(nsName)).WithTrailingTrivia(SyntaxFactory.CarriageReturnLineFeed);
                var firstNonUsing = root.ChildNodes().FirstOrDefault(n => n is not UsingDirectiveSyntax && n.Kind() != SyntaxKind.ShebangDirectiveTrivia);
                var usings = root.DescendantNodes().OfType<UsingDirectiveSyntax>().ToList();
                SyntaxNode newRoot;
                if (usings.Count > 0)
                {
                    var lastUsing = usings.Last();
                    newRoot = root.InsertNodesAfter(lastUsing, new[] { usingDirective });
                }
                else if (firstNonUsing != null)
                {
                    newRoot = root.InsertNodesBefore(firstNonUsing, new[] { usingDirective });
                }
                else
                {
                    // root has no usings; prepend at top
                    newRoot = root.WithLeadingTrivia(usingDirective.GetLeadingTrivia())
                                   .InsertNodesBefore(root.ChildNodes().FirstOrDefault()!, new[] { usingDirective });
                }
                var newText = newRoot.NormalizeWhitespace().ToFullString();
                return newText;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("AddUsingIfUniqueTypeAsync error: " + ex.Message);
                return null;
            }
        }


        public static async Task<string?> FormatCSharpAsync(string source, bool useTabs, int indentSize, CancellationToken ct = default)
        {
            try
            {
                // Workspace mit Standard-HostServices (MEF) aufbauen
                using var workspace = new AdhocWorkspace(MefHostServices.DefaultHost);

                // Options setzen (Tabs/Indent-Sizes wie VS Code)
                var options = workspace.Options
                    .WithChangedOption(FormattingOptions.UseTabs, LanguageNames.CSharp, useTabs)
                    .WithChangedOption(FormattingOptions.IndentationSize, LanguageNames.CSharp, indentSize)
                    .WithChangedOption(FormattingOptions.TabSize, LanguageNames.CSharp, indentSize);

                // SyntaxTree parsen
                var syntaxTree = CSharpSyntaxTree.ParseText(source, new CSharpParseOptions(LanguageVersion.Preview), cancellationToken: ct);
                var root = await syntaxTree.GetRootAsync(ct).ConfigureAwait(false);

                // Dokument in Projekt legen
                var projId = ProjectId.CreateNewId();
                var docId = DocumentId.CreateNewId(projId);

                var solution = workspace.CurrentSolution
                    .AddProject(projId, "AdhocProject", "AdhocProject", LanguageNames.CSharp)
                    .WithProjectCompilationOptions(projId, new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary))
                    .AddDocument(docId, "Temp.cs", SourceText.From(source, Encoding.UTF8));

                if (!workspace.TryApplyChanges(solution))
                    return null;

                var document = workspace.CurrentSolution.GetDocument(docId)!;

                // Root in Document injizieren, dann formatieren
                document = document.WithSyntaxRoot(root);
                var formattedDoc = await Formatter.FormatAsync(document, options, ct).ConfigureAwait(false);
                var formattedText = await formattedDoc.GetTextAsync(ct).ConfigureAwait(false);

                return formattedText.ToString();
            }
            catch
            {
                // Wenn Roslyn fehlt oder eine Exception wirft → Fallback erlauben
                return null;
            }
        }
    }
}
