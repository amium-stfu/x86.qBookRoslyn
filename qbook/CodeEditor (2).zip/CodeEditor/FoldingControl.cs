﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Text;
using ScintillaNET;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using static qbook.CodeEditor.FormEditor;

namespace qbook.CodeEditor
{
    internal class FoldingControl
    {
        ScintillaNET.Scintilla Editor;
        FormEditor Root;

        public FoldingControl(FormEditor root)
        {
            Root = root;
            this.Editor = Root.Editor;

           // Editor.KeyDown += Editor_KeyDown;
        }

        public void Initialize()
        {
            const int MARGIN_FOLD = 2;
            Editor.SetProperty("fold", "1");
            Editor.SetProperty("fold.compact", "1");
            Editor.SetProperty("fold.preprocessor", "1");
            Editor.SetProperty("fold.line", "0");


            Editor.Margins[MARGIN_FOLD].Type = MarginType.Symbol;
            Editor.Margins[MARGIN_FOLD].Sensitive = true;
            Editor.Margins[MARGIN_FOLD].Mask = Marker.MaskFolders;
            Editor.Margins[MARGIN_FOLD].Width = 20;

            Editor.Markers[Marker.Folder].Symbol = MarkerSymbol.Arrow;
            Editor.Markers[Marker.FolderOpen].Symbol = MarkerSymbol.ArrowDown;
            Editor.Markers[Marker.FolderSub].Symbol = MarkerSymbol.VLine;
            Editor.Markers[Marker.FolderTail].Symbol = MarkerSymbol.LCorner;
            Editor.Markers[Marker.FolderMidTail].Symbol = MarkerSymbol.TCorner;
            Editor.Markers[Marker.FolderEnd].Symbol = MarkerSymbol.Arrow;
            Editor.Markers[Marker.FolderOpenMid].Symbol = MarkerSymbol.ArrowDown;

            int[] folderMarkers = new[] {
            Marker.Folder,
            Marker.FolderOpen,
            Marker.FolderEnd,
            Marker.FolderOpenMid,
            Marker.FolderMidTail,
            Marker.FolderSub,
            Marker.FolderTail
            };

            var fore = Color.FromArgb(0x60, 0x60, 0x60);
            var back = Color.FromArgb(0xE0, 0xE0, 0xE0);


            fore = Color.DarkGray;
            back = Color.DarkGray;



            foreach (var i in folderMarkers)
            {
                Editor.Markers[i].SetForeColor(fore);
                Editor.Markers[i].SetBackColor(back);
            }

            Editor.AutomaticFold = AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change;
        }
        public class BraceBlock
        {
            public int OpenPos;
            public int ClosePos;
            public int OpenLine;
            public int CloseLine;
            public List<BraceBlock> Children = new();
            public BraceBlock? Parent; // NEU
            public bool Contains(int pos) => OpenPos <= pos && pos <= ClosePos;
        }
        public List<BraceBlock> BuildBraceForest()
        {
            var forest = new List<BraceBlock>();
            var stack = new Stack<BraceBlock>();
            for (int pos = 0; pos < Editor.TextLength; pos++)
            {
                int ch = Editor.GetCharAt(pos);
                if (ch == '{')
                {
                    var blk = new BraceBlock { OpenPos = pos, OpenLine = Editor.LineFromPosition(pos) };
                    if (stack.Count == 0) forest.Add(blk); else { var parent = stack.Peek(); parent.Children.Add(blk); blk.Parent = parent; }
                    stack.Push(blk);
                }
                else if (ch == '}' && stack.Count > 0)
                {
                    var blk = stack.Pop();
                    blk.ClosePos = pos;
                    blk.CloseLine = Editor.LineFromPosition(pos);
                }
            }
            forest = forest.Where(b => b.ClosePos > b.OpenPos).ToList();

            // Filter: entferne Auto-Property Accessor-Blöcke (z.B. { get; set; }) damit Methoden als direkte Kinder erkannt werden
            bool IsAccessorBlock(BraceBlock b)
            {
                if (b.OpenLine != b.CloseLine) return false; // nur einzeilige
                int innerLen = b.ClosePos - b.OpenPos - 1;
                if (innerLen <= 0) return false;
                string inner = Editor.GetTextRange(b.OpenPos + 1, innerLen);
                // Nur Schlüsselwörter get/set/init ; und evtl. Whitespace
                if (System.Text.RegularExpressions.Regex.IsMatch(inner, @"^\s*(?:get|set|init);(?:\s*(?:get|set|init);)*\s*$")) return true;
                return false;
            }
            void Prune(List<BraceBlock> list)
            {
                for (int i = list.Count - 1; i >= 0; i--)
                {
                    var b = list[i];
                    if (IsAccessorBlock(b)) { list.RemoveAt(i); continue; }
                    Prune(b.Children);
                }
            }
            Prune(forest);
            return forest;
        }
        public BraceBlock? FindDeepestContaining(BraceBlock blk, int caret)
        {
            if (!blk.Contains(caret)) return null;
            foreach (var child in blk.Children)
            {
                var hit = FindDeepestContaining(child, caret);
                if (hit != null) return hit;
            }
            return blk;
        }
        public ((int openLine, int closeLine, int openPos, int closePos)? parent, List<(int openLine, int closeLine, int openPos, int closePos)> directChildren) GetParentAndDirectChildren()
        {
            var forest = BuildBraceForest();
            int caret = Editor.CurrentPosition;
            BraceBlock? deepest = null;
            foreach (var root in forest)
            {
                var hit = FindDeepestContaining(root, caret);
                if (hit != null)
                {
                    if (deepest == null || (hit.OpenPos >= deepest.OpenPos && hit.ClosePos <= deepest.ClosePos)) deepest = hit;
                }
            }
            if (deepest == null) return (null, new());
            // Heuristik: Wenn wir in einem Block ohne Geschwister (oder mit Parent der viele Kinder hat) und der Block klein ist (z.B. if/loop innerhalb einer Methode), wähle einen höheren Block mit mehreren Kindern (z.B. Methoden innerhalb Klasse)
            BraceBlock chosen = deepest;
            bool IsSmall(BraceBlock b) => (b.CloseLine - b.OpenLine) < 3; // sehr kleiner Block
            if (chosen.Parent != null)
            {
                // Wenn der Parent >1 Kinder hat und chosen entweder klein ist oder Parent deutlich größer ist -> Parent benutzen
                if (chosen.Parent.Children.Count > 1 && (IsSmall(chosen) || (chosen.Parent.CloseLine - chosen.Parent.OpenLine) > (chosen.CloseLine - chosen.OpenLine) * 2))
                {
                    chosen = chosen.Parent;
                }
                else
                {
                    // Eine Ebene höher weiter gehen bis wir einen Block mit >1 Kindern finden (Klassenblock) falls aktueller nur genau ein Child enthält
                    var ascend = chosen;
                    while (ascend.Parent != null && ascend.Parent.Children.Count <= 1)
                        ascend = ascend.Parent;
                    if (ascend.Parent != null && ascend.Parent.Children.Count > 1)
                        chosen = ascend.Parent;
                }
            }
            var resultChildren = chosen.Children
                .Where(c => c.ClosePos > c.OpenPos)
                .Select(c => (c.OpenLine, c.CloseLine, c.OpenPos, c.ClosePos))
                .ToList();
            return ((chosen.OpenLine, chosen.CloseLine, chosen.OpenPos, chosen.ClosePos), resultChildren);
        }
        public async Task CollapseAllInnerBlocksExceptOuter()
        {
            EditorNode node = Root.SelectedNode;
            
            var (parent, directChildren) = GetParentAndDirectChildren();
            if (parent == null || directChildren.Count == 0) return;
            foreach (var b in directChildren)
                if (!LineIsCollapsed(Editor, b.openLine)) Editor.Lines[b.openLine].ToggleFold();

            //node.RoslynDoc = node.RoslynDoc.WithText(SourceText.From(Editor.Text));
            var tree = await node.RoslynDoc.GetSyntaxTreeAsync();
            node.Foldings = SaveFoldedMethodNames(tree);
        }
        public void ExpandAllBlocksAtCaret()
        {
            var (parent, directChildren) = GetParentAndDirectChildren();
            if (parent == null) return;
            foreach (var b in directChildren)
                if (LineIsCollapsed(Editor, b.openLine)) Editor.Lines[b.openLine].ToggleFold();
        }
        public static bool LineIsCollapsed(Scintilla sci, int headerLine)
        {
            if (headerLine + 1 >= sci.Lines.Count) return false;
            return !sci.Lines[headerLine + 1].Visible;
        }

        public bool CopyBlockIfHeaderLineSelected()
        {
            int selStart = Editor.SelectionStart;
            int selEnd = Editor.SelectionEnd;

            Debug.WriteLine($"[Copy] SelectionStart: {selStart}, SelectionEnd: {selEnd}");

            int startLine = Editor.LineFromPosition(selStart);
            int endLine = Editor.LineFromPosition(selEnd);

            if (endLine > startLine && Editor.Lines[endLine].Position == selEnd)
            {
                Debug.WriteLine("[Copy] Selection ends at start of next line – adjusting endLine.");
                endLine--;
            }

            if (startLine != endLine)
            {
                Debug.WriteLine("[Copy] Selection spans multiple lines – aborting.");
                return false;
            }

            var block = GetBlockAtCaret();
            if (block == null)
            {
                Debug.WriteLine("[Copy] No block found at caret.");
                return false;
            }

            var (openLine, closeLine, openPos, closePos) = block.Value;

            if (startLine != openLine)
            {
                Debug.WriteLine("[Copy] Selected line is not the header line of the block.");
                return false;
            }

            // Kopiere ab Zeilenanfang der Header-Zeile bis zum Block-Ende
            int startPos = Editor.Lines[openLine].Position;
            string fullBlock = Editor.GetTextRange(startPos, closePos - startPos + 1);

            Debug.WriteLine($"[Copy] Copied block text length: {fullBlock.Length}");

            System.Windows.Forms.Clipboard.SetText(fullBlock);
            return true;
        }

        public (int openLine, int closeLine, int openPos, int closePos)? GetBlockAtCaret()
        {
            var forest = BuildBraceForest();
            int caret = Editor.CurrentPosition;

            foreach (var root in forest)
            {
                var hit = FindDeepestContaining(root, caret);
                if (hit != null)
                {
                    return (hit.OpenLine, hit.CloseLine, hit.OpenPos, hit.ClosePos);
                }
            }

            return null;
        }

        public List<(int openPos, int closePos)> SaveFoldedBlocks()
        {
            var folded = new List<(int, int)>();
            var forest = BuildBraceForest();

            void Collect(BraceBlock b)
            {
                if (!Editor.Lines[b.OpenLine + 1].Visible)
                {
                    folded.Add((b.OpenPos, b.ClosePos));
                }

                foreach (var child in b.Children)
                    Collect(child);
            }

            foreach (var root in forest)
                Collect(root);

            return folded;
        }


        private string GetBlockSignature(BraceBlock b)
        {
            string headerLine = Editor.Lines[b.OpenLine].Text.Trim();
            string firstLine = Editor.GetTextRange(b.OpenPos, Math.Min(50, Editor.TextLength - b.OpenPos)).Trim();
            string sig = $"{b.OpenLine}:{headerLine}:{firstLine}";
            Debug.WriteLine($"[Signature] Block at line {b.OpenLine} → {sig}");
            return sig;
        }


        public List<string> SaveFoldedBlockSignatures()
        {
            var foldedSignatures = new List<string>();
            var forest = BuildBraceForest();

            void Collect(BraceBlock b)
            {
                if (!Editor.Lines[b.OpenLine + 1].Visible)
                {
                    string signature = GetBlockSignature(b);
                    foldedSignatures.Add(signature);
                }

                foreach (var child in b.Children)
                    Collect(child);
            }

            foreach (var root in forest)
                Collect(root);

            return foldedSignatures;
        }

        public void RestoreFoldedBlockSignatures(List<string> foldedSignatures)
        {
            Debug.WriteLine($"[Restore] Begin restoring {foldedSignatures.Count} folded blocks...");

            var forest = BuildBraceForest();
            int restoredCount = 0;

            void Restore(BraceBlock b)
            {
                string sig = GetBlockSignature(b);
                Debug.WriteLine($"[Restore] Checking block at line {b.OpenLine}: {sig}");

                if (foldedSignatures.Contains(sig))
                {
                    if (Editor.Lines[b.OpenLine + 1].Visible)
                    {
                        Debug.WriteLine($"[Restore] Folding block at line {b.OpenLine}");
                        Editor.Lines[b.OpenLine].ToggleFold();
                        restoredCount++;
                    }
                    else
                    {
                        Debug.WriteLine($"[Restore] Block at line {b.OpenLine} already folded");
                    }
                }

                foreach (var child in b.Children)
                    Restore(child);
            }

            foreach (var root in forest)
                Restore(root);

            Debug.WriteLine($"[Restore] Done. Restored {restoredCount} blocks.");
        }


        public void RestoreFoldedBlocks(List<(int openPos, int closePos)> folded)
        {
            var forest = BuildBraceForest();

            void Restore(BraceBlock b)
            {
                foreach (var (open, close) in folded)
                {
                    if (b.OpenPos == open && b.ClosePos == close)
                    {
                        if (Editor.Lines[b.OpenLine + 1].Visible)
                            Editor.Lines[b.OpenLine].ToggleFold();
                        break;
                    }
                }

                foreach (var child in b.Children)
                    Restore(child);
            }

            foreach (var root in forest)
                Restore(root);
        }


        public List<string> SaveFoldedMethodNames(SyntaxTree tree)
        {
            var root = tree.GetRoot();
            var folded = new List<string>();

            foreach (var method in root.DescendantNodes().OfType<MethodDeclarationSyntax>())
            {
                int line = Editor.LineFromPosition(method.SpanStart);
                bool isHeader = (Editor.Lines[line].FoldLevelFlags & FoldLevelFlags.Header) != 0;
                bool isCollapsed = !Editor.Lines[line + 1].Visible;

                //Debug.WriteLine($"[RoslynFold] Saved folded method: {method.Identifier.Text}");
                //Debug.WriteLine($"  Line: {line}");
                //Debug.WriteLine($"  FoldLevelFlags: {Editor.Lines[line].FoldLevelFlags}");
                //Debug.WriteLine($"  IsHeader: {isHeader}");
                //Debug.WriteLine($"  IsCollapsed: {isCollapsed}");
                //Debug.WriteLine("===================================");

                if (isHeader && isCollapsed)
                {
                    folded.Add(method.Identifier.Text);
                }
            }

    //        Debug.WriteLine($"[RoslynFold] Total folded methods saved: {folded.Count}");
            return folded;
        }

        public void RestoreFoldedMethodNames(SyntaxTree tree, List<string> foldedMethodNames)
        {
            Initialize();
            var root = tree.GetRoot();
            int restored = 0;

            if (foldedMethodNames == null)
            {
                Debug.WriteLine("[RoslynFold] No folded methods to restore.");
                return;
            }

            foreach (var method in root.DescendantNodes().OfType<MethodDeclarationSyntax>())
            {
                string methodName = method.Identifier.Text;
                int line = Editor.LineFromPosition(method.SpanStart);
                var flags = Editor.Lines[line].FoldLevelFlags;
                bool isHeader = (flags & FoldLevelFlags.Header) != 0;
                bool isCollapsed = !Editor.Lines[line + 1].Visible;

                bool shouldRestore = foldedMethodNames.Contains(methodName);

                //Debug.WriteLine($"[RoslynFold] Method: {methodName}");
                //Debug.WriteLine($"  Line: {line}");
                //Debug.WriteLine($"  FoldLevelFlags: {flags}");
                //Debug.WriteLine($"  IsHeader: {isHeader}");
                //Debug.WriteLine($"  IsCollapsed: {isCollapsed}");
                //Debug.WriteLine($"  ShouldRestore: {shouldRestore}");
                //Debug.WriteLine("===================================");

                if (shouldRestore && isHeader && !isCollapsed)
                {
                    Editor.Lines[line].ToggleFold();
              //      Debug.WriteLine($"  → Fold restored");
                    restored++;
                }
                else if (shouldRestore && isCollapsed)
                {
             //       Debug.WriteLine($"  → Already folded");
                }
                else
                {
          //          Debug.WriteLine($"  → No action");
                }
            }

        //    Debug.WriteLine($"[RoslynFold] Total folds restored: {restored}");
        }







        private void Editor_KeyDown(object? sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == System.Windows.Forms.Keys.C)
            {

                bool copied = CopyBlockIfHeaderLineSelected();
                if (copied)
                {
                    // Wir haben den Block kopiert → Standardverhalten unterdrücken
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }

            }
        }






    }
}
