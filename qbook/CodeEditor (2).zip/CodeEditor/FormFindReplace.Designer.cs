﻿namespace qbook.CodeEditor
{
    partial class FormFindReplace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tbFind = new System.Windows.Forms.TextBox();
            this.tbReplace = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnFindNext = new System.Windows.Forms.Button();
            this.btnFindPrevious = new System.Windows.Forms.Button();
            this.btnReplaceNext = new System.Windows.Forms.Button();
            this.btnReplaceAll = new FontAwesome.Sharp.IconButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbTarget = new System.Windows.Forms.ComboBox();
            this.btnMatchCase = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.45977F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 94.54023F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.Controls.Add(this.tbFind, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tbReplace, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnClose, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnFindNext, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnFindPrevious, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnReplaceNext, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnReplaceAll, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(358, 114);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tbFind
            // 
            this.tbFind.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbFind.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbFind.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFind.Location = new System.Drawing.Point(15, 5);
            this.tbFind.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tbFind.Name = "tbFind";
            this.tbFind.Size = new System.Drawing.Size(214, 22);
            this.tbFind.TabIndex = 0;
            this.tbFind.Text = "Find...";
            this.tbFind.TextChanged += new System.EventHandler(this.tbFind_TextChanged);
            // 
            // tbReplace
            // 
            this.tbReplace.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbReplace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbReplace.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbReplace.Location = new System.Drawing.Point(15, 44);
            this.tbReplace.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tbReplace.Name = "tbReplace";
            this.tbReplace.Size = new System.Drawing.Size(214, 22);
            this.tbReplace.TabIndex = 1;
            this.tbReplace.Text = "Replace...";
            this.tbReplace.TextChanged += new System.EventHandler(this.tbReplace_TextChanged);
            // 
            // btnClose
            // 
            this.btnClose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnClose.Location = new System.Drawing.Point(325, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 33);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnFindNext
            // 
            this.btnFindNext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFindNext.Location = new System.Drawing.Point(280, 3);
            this.btnFindNext.Name = "btnFindNext";
            this.btnFindNext.Size = new System.Drawing.Size(39, 33);
            this.btnFindNext.TabIndex = 3;
            this.btnFindNext.Text = ">";
            this.btnFindNext.UseVisualStyleBackColor = true;
            this.btnFindNext.Click += new System.EventHandler(this.btnFindNext_Click);
            // 
            // btnFindPrevious
            // 
            this.btnFindPrevious.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFindPrevious.Location = new System.Drawing.Point(235, 3);
            this.btnFindPrevious.Name = "btnFindPrevious";
            this.btnFindPrevious.Size = new System.Drawing.Size(39, 33);
            this.btnFindPrevious.TabIndex = 4;
            this.btnFindPrevious.Text = "<";
            this.btnFindPrevious.UseVisualStyleBackColor = true;
            this.btnFindPrevious.Click += new System.EventHandler(this.btnFindPrevious_Click);
            // 
            // btnReplaceNext
            // 
            this.btnReplaceNext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnReplaceNext.Location = new System.Drawing.Point(235, 42);
            this.btnReplaceNext.Name = "btnReplaceNext";
            this.btnReplaceNext.Size = new System.Drawing.Size(39, 33);
            this.btnReplaceNext.TabIndex = 5;
            this.btnReplaceNext.Text = ">";
            this.btnReplaceNext.UseVisualStyleBackColor = true;
            this.btnReplaceNext.Click += new System.EventHandler(this.btnReplaceNext_Click);
            // 
            // btnReplaceAll
            // 
            this.btnReplaceAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnReplaceAll.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnReplaceAll.IconColor = System.Drawing.Color.Black;
            this.btnReplaceAll.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnReplaceAll.Location = new System.Drawing.Point(280, 42);
            this.btnReplaceAll.Name = "btnReplaceAll";
            this.btnReplaceAll.Size = new System.Drawing.Size(39, 33);
            this.btnReplaceAll.TabIndex = 6;
            this.btnReplaceAll.Text = "all";
            this.btnReplaceAll.UseVisualStyleBackColor = true;
            this.btnReplaceAll.Click += new System.EventHandler(this.btnReplaceAll_Click);
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 3);
            this.panel1.Controls.Add(this.cbTarget);
            this.panel1.Controls.Add(this.btnMatchCase);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(15, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(304, 30);
            this.panel1.TabIndex = 7;
            // 
            // cbTarget
            // 
            this.cbTarget.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTarget.FormattingEnabled = true;
            this.cbTarget.Items.AddRange(new object[] {
            "Document",
            "Selection",
            "Project"});
            this.cbTarget.Location = new System.Drawing.Point(32, 0);
            this.cbTarget.Name = "cbTarget";
            this.cbTarget.Size = new System.Drawing.Size(272, 26);
            this.cbTarget.TabIndex = 1;
            this.cbTarget.Text = "Document";
            // 
            // btnMatchCase
            // 
            this.btnMatchCase.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMatchCase.Location = new System.Drawing.Point(0, 0);
            this.btnMatchCase.Name = "btnMatchCase";
            this.btnMatchCase.Size = new System.Drawing.Size(32, 30);
            this.btnMatchCase.TabIndex = 0;
            this.btnMatchCase.Text = "Aa";
            this.btnMatchCase.UseVisualStyleBackColor = true;
            this.btnMatchCase.Click += new System.EventHandler(this.btnMatchCase_Click);
            // 
            // FormFindReplace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 114);
            this.ControlBox = false;
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormFindReplace";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "FormFindReplace";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FormFindReplace_Load);
            this.Shown += new System.EventHandler(this.FormFindReplace_Shown);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox tbFind;
        private System.Windows.Forms.TextBox tbReplace;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnFindNext;
        private System.Windows.Forms.Button btnFindPrevious;
        private System.Windows.Forms.Button btnReplaceNext;
        private FontAwesome.Sharp.IconButton btnReplaceAll;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnMatchCase;
        private System.Windows.Forms.ComboBox cbTarget;
    }
}