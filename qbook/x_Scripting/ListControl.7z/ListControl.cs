﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class ListControl : UserControl
    {
        public ListControl()
        {
            InitializeComponent();

            this.DoubleBuffered = true;

            this.MouseWheel += ListControl_MouseWheel;

            this.SuspendLayout();
            // 
            // ListControl
            // 
            this.Name = "ListControl";
            this.DoubleClick += new System.EventHandler(this.ListControl_DoubleClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ListControl_MouseDown);
            this.ResumeLayout(false);
        }

        private void ListControl_MouseWheel(object sender, MouseEventArgs e)
        {
            int itemCount = this.Height / itemHeight;

            TopItemIndex -= e.Delta/20;
            if (TopItemIndex < 0)
                TopItemIndex = 0;
            if (TopItemIndex > Items.Count - itemCount)
                TopItemIndex = Items.Count - itemCount -1;
            this.Invalidate();
        }

        public List<object> Items = new List<object>();

        int TopItemIndex = 0;
        //int ItemCount = 10;

        Font ItemFont = new Font("Consolas", 8);
        int itemHeight = 12;
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            try
            {
                int itemCount = this.Height / itemHeight;

                vScrollBar1.Minimum = 0;
                vScrollBar1.Maximum = Math.Max(0, Items.Count); // - itemCount * 5 / 6); //TODO: !!!
                if (TopItemIndex < 0)
                    TopItemIndex = 0;
                vScrollBar1.Value = Math.Min(TopItemIndex, vScrollBar1.Maximum);

                if (Items != null && Items.Count > 0)
                {

                    for (int i = 0; i < itemCount; i++)
                    {
                        if (Items.Count > TopItemIndex + i)
                        {
                            e.Graphics.DrawString(Items[TopItemIndex + i].ToString(), ItemFont, Brushes.Black, new Rectangle(1, 1 + i * itemHeight, this.Width - 1, itemHeight));
                        }
                    }
                }
            } catch (Exception ex)
            {
                e.Graphics.DrawLine(Pens.Red, 0, 0, this.Width, this.Height);
                e.Graphics.DrawLine(Pens.Red, 0, this.Width, 0, this.Height);
            }
            
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            TopItemIndex = e.NewValue;
            this.Invalidate();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ListControl
            // 
            this.Name = "ListControl";
            this.DoubleClick += new System.EventHandler(this.ListControl_DoubleClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ListControl_MouseDown);
            this.ResumeLayout(false);

        }

        private void ListControl_DoubleClick(object sender, EventArgs e)
        {
            int rowId = TopItemIndex + LastMousePos.Y / itemHeight;
            var item = Items[rowId];

        }

        Point LastMousePos = Point.Empty;
        private void ListControl_MouseDown(object sender, MouseEventArgs e)
        {
            LastMousePos = e.Location;
        }
    }
}
